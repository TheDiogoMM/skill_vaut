# SkillVault — Web UI Kit

Click-through recreation of the SkillVault desktop-first web app: Catálogo, Detalhe do item, Adicionar (repo/skill/mcp) e Recomendar. Composes design-system components (`Sidebar`, `ItemCard`, `TypeBadge`, `Tabs`, `Input`, `Select`, `Textarea`, `Button`, `StatusMessage`, `Icon`). Mock data lives in `mock-data.js`.

Source app: no visual styling existed in the original codebase beyond `apps/web/src/theme.css` (raw semantic HTML) — this kit is the first fully-designed version of these screens, following the routes and interactions defined in `docs/superpowers/specs/2026-07-16-skillvault-design.md`.
