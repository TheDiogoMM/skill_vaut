window.App = function App() {
  const { Sidebar } = window.SkillVaultDesignSystem_31593f;
  const [theme, setTheme] = React.useState('dark');
  const [route, setRoute] = React.useState('catalog');
  const [openId, setOpenId] = React.useState(null);
  const [items, setItems] = React.useState(window.MOCK_ITEMS);
  const [categories, setCategories] = React.useState(window.MOCK_CATEGORIES);
  const [toast, setToast] = React.useState('');

  React.useEffect(() => { document.documentElement.setAttribute('data-theme', theme); }, [theme]);

  function handleOpenItem(id) { setOpenId(id); setRoute('detail'); }
  function handleBack() { setOpenId(null); setRoute('catalog'); }
  function handleSaveItem(patch) { setItems(items.map(it => it.id === openId ? { ...it, ...patch } : it)); }
  function handleRenameCategory(id, name) { setCategories(categories.map(c => c.id === id ? { ...c, name } : c)); }
  function handleMergeCategory(srcId, tgtId) {
    setItems(items.map(it => it.categoryId === srcId ? { ...it, categoryId: tgtId } : it));
    setCategories(categories.filter(c => c.id !== srcId));
  }
  function handleCreated(type, name) {
    const nextId = Math.max(...items.map(i => i.id)) + 1;
    const newItem = { id: nextId, type, name, categoryId: null, summary: 'Enriquecendo via LLM...', utility: '', tags: [], localPath: `~/skillvault/${type}s/${name}`, enrichmentSource: 'manual', content: `# ${name}\n\nConteúdo recém-adicionado.` };
    setItems([...items, newItem]);
    setToast(`"${name}" adicionado ao catálogo.`);
    setTimeout(() => setToast(''), 2400);
    handleOpenItem(nextId);
  }

  const openItem = items.find(i => i.id === openId);

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--color-bg)' }}>
      <Sidebar active={route === 'detail' ? 'catalog' : route} onNavigate={(k) => { setRoute(k); setOpenId(null); }} theme={theme} onToggleTheme={() => setTheme(t => t === 'dark' ? 'light' : 'dark')} />
      <main style={{ flex: 1, padding: 32, position: 'relative' }}>
        {toast && <div style={{ position: 'fixed', top: 20, right: 20, background: 'var(--color-surface-raised)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: '10px 16px', fontFamily: 'var(--font-sans)', fontSize: 13, color: 'var(--color-text)', boxShadow: 'var(--shadow-md)' }}>{toast}</div>}
        {route === 'catalog' && <window.CatalogScreen items={items} categories={categories} onOpenItem={handleOpenItem} onRenameCategory={handleRenameCategory} onMergeCategory={handleMergeCategory} />}
        {route === 'detail' && openItem && <window.ItemDetailScreen item={openItem} categories={categories} onBack={handleBack} onSave={handleSaveItem} />}
        {route === 'add' && <window.AddScreen categories={categories} onCreated={handleCreated} />}
        {route === 'recommend' && <window.RecommendScreen items={items} />}
      </main>
    </div>
  );
};
