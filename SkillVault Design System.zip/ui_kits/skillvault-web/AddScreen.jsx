window.AddScreen = function AddScreen({ categories, onCreated }) {
  const { Select, Input, Textarea, Tabs, Button, StatusMessage, Icon } = window.SkillVaultDesignSystem_31593f;
  const [type, setType] = React.useState('repo');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20, maxWidth: 520 }}>
      <h1 style={{ margin: 0, fontFamily: 'var(--font-sans)', fontSize: 'var(--text-display)', fontWeight: 'var(--fw-display)', color: 'var(--color-text)' }}>Adicionar item</h1>
      <Select label="Tipo" value={type} onChange={e => setType(e.target.value)} style={{ width: 220 }}>
        <option value="repo">Repositório</option>
        <option value="skill">Skill</option>
        <option value="mcp">MCP</option>
      </Select>
      {type === 'repo' && <RepoForm onCreated={onCreated} />}
      {type === 'skill' && <SkillForm onCreated={onCreated} />}
      {type === 'mcp' && <McpForm onCreated={onCreated} />}
    </div>
  );
};

function RepoForm({ onCreated }) {
  const { Input, Button, StatusMessage } = window.SkillVaultDesignSystem_31593f;
  const [name, setName] = React.useState('');
  const [url, setUrl] = React.useState('');
  const [status, setStatus] = React.useState('idle');
  function submit(e) {
    e.preventDefault();
    setStatus('submitting');
    setTimeout(() => { setStatus('idle'); onCreated('repo', name || 'novo-repo'); }, 500);
  }
  return (
    <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 14, background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-lg)', padding: 18 }}>
      <Input label="Nome" value={name} onChange={e => setName(e.target.value)} placeholder="fastify-starter" required />
      <Input label="URL do repositório" value={url} onChange={e => setUrl(e.target.value)} placeholder="https://github.com/org/repo.git" required />
      <div><Button disabled={status === 'submitting'}>{status === 'submitting' ? 'Clonando...' : 'Adicionar repositório'}</Button></div>
    </form>
  );
}

function SkillForm({ onCreated }) {
  const { Input, Tabs, Button } = window.SkillVaultDesignSystem_31593f;
  const [name, setName] = React.useState('');
  const [tab, setTab] = React.useState('local_path');
  const [status, setStatus] = React.useState('idle');
  function submit(e) {
    e.preventDefault();
    setStatus('submitting');
    setTimeout(() => { setStatus('idle'); onCreated('skill', name || 'nova-skill'); }, 500);
  }
  return (
    <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 14, background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-lg)', padding: 18 }}>
      <Input label="Nome" value={name} onChange={e => setName(e.target.value)} placeholder="pdf-parser" required />
      <Tabs tabs={[{ value: 'local_path', label: 'Caminho local' }, { value: 'upload', label: 'Upload' }, { value: 'url', label: 'URL' }]} value={tab} onChange={setTab} />
      {tab === 'local_path' && <Input label="Caminho local da pasta" placeholder="C:\\Users\\Diogo\\skills\\pdf-parser" required />}
      {tab === 'upload' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <label style={{ fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: 'var(--color-text-secondary)' }}>Arquivo (SKILL.md ou .zip)</label>
          <div style={{ border: '1px dashed var(--color-border-strong)', borderRadius: 'var(--radius-md)', padding: '18px', textAlign: 'center', color: 'var(--color-text-tertiary)', fontFamily: 'var(--font-sans)', fontSize: 13 }}>Arraste um arquivo ou clique para selecionar</div>
        </div>
      )}
      {tab === 'url' && <Input label="URL do repositório da skill" placeholder="https://github.com/org/skill.git" required />}
      <div><Button disabled={status === 'submitting'}>{status === 'submitting' ? 'Enviando...' : 'Adicionar skill'}</Button></div>
    </form>
  );
}

function McpForm({ onCreated }) {
  const { Input, Textarea, Button } = window.SkillVaultDesignSystem_31593f;
  const [name, setName] = React.useState('');
  const [config, setConfig] = React.useState('{\n  "mcpServers": {\n    "example": { "command": "npx", "args": ["-y", "@example/mcp"] }\n  }\n}');
  const [status, setStatus] = React.useState('idle');
  function submit(e) {
    e.preventDefault();
    setStatus('submitting');
    setTimeout(() => { setStatus('idle'); onCreated('mcp', name || 'novo-mcp'); }, 500);
  }
  return (
    <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 14, background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-lg)', padding: 18 }}>
      <Input label="Nome" value={name} onChange={e => setName(e.target.value)} placeholder="filesystem-mcp" required />
      <Input label="Descrição (opcional)" placeholder="Acesso ao sistema de arquivos" />
      <Textarea label="Config JSON (ex: bloco mcpServers)" mono value={config} onChange={e => setConfig(e.target.value)} required />
      <div><Button disabled={status === 'submitting'}>{status === 'submitting' ? 'Salvando...' : 'Adicionar MCP'}</Button></div>
    </form>
  );
}
