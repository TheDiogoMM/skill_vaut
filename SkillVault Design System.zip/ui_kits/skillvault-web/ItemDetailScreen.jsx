window.ItemDetailScreen = function ItemDetailScreen({ item, categories, onBack, onSave }) {
  const { TypeBadge, Button, Select, Input, Tag, StatusMessage, Icon } = window.SkillVaultDesignSystem_31593f;
  const [copied, setCopied] = React.useState(false);
  const [categoryId, setCategoryId] = React.useState(item.categoryId != null ? String(item.categoryId) : '');
  const [tagsInput, setTagsInput] = React.useState(item.tags.join(', '));
  const [saveStatus, setSaveStatus] = React.useState('idle');

  function handleCopy() {
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }
  function handleSave() {
    setSaveStatus('saving');
    setTimeout(() => {
      onSave({ categoryId: categoryId ? Number(categoryId) : null, tags: tagsInput.split(',').map(t => t.trim()).filter(Boolean) });
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 1600);
    }, 400);
  }

  const isMcp = item.type === 'mcp';
  const enrichmentLabel = { ollama: 'Ollama (local)', gemini: 'Gemini 2.0 Flash', manual: 'Manual' }[item.enrichmentSource];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20, maxWidth: 760 }}>
      <button type="button" onClick={onBack} style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'none', border: 'none', color: 'var(--color-text-tertiary)', fontFamily: 'var(--font-sans)', fontSize: 13, cursor: 'pointer', padding: 0, alignSelf: 'flex-start' }}>
        <Icon name="arrow-left" size={14} /> Voltar ao catálogo
      </button>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <h1 style={{ margin: 0, fontFamily: 'var(--font-sans)', fontSize: 'var(--text-display)', fontWeight: 'var(--fw-display)', color: 'var(--color-text)' }}>{item.name}</h1>
        <TypeBadge type={item.type} />
      </div>
      <p style={{ margin: 0, fontFamily: 'var(--font-sans)', fontSize: 15, color: 'var(--color-text-secondary)' }}>{item.summary}</p>
      <p style={{ margin: 0, fontFamily: 'var(--font-sans)', fontSize: 14, color: 'var(--color-text-tertiary)' }}>{item.utility}</p>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
        <code style={{ background: 'var(--color-bg-inset)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)', padding: '6px 10px', fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--color-text-secondary)' }}>{item.localPath}</code>
        <Button variant="secondary" size="sm" iconLeft={<Icon name={copied ? 'check' : 'copy'} size={13} />} onClick={handleCopy}>{copied ? 'Copiado!' : 'Copiar caminho'}</Button>
        <span style={{ fontFamily: 'var(--font-sans)', fontSize: 12, color: 'var(--color-text-tertiary)' }}>Enriquecido via {enrichmentLabel}</span>
      </div>

      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-end', background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-lg)', padding: 16, flexWrap: 'wrap' }}>
        <Select label="Categoria" value={categoryId} onChange={e => setCategoryId(e.target.value)} style={{ width: 200 }}>
          <option value="">Sem categoria</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
        <Input label="Tags (separadas por vírgula)" value={tagsInput} onChange={e => setTagsInput(e.target.value)} style={{ width: 260 }} />
        <Button onClick={handleSave} disabled={saveStatus === 'saving'}>Salvar</Button>
        {saveStatus === 'saved' && <StatusMessage kind="success">Salvo!</StatusMessage>}
      </div>

      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        {tagsInput.split(',').map(t => t.trim()).filter(Boolean).map(t => <Tag key={t}>{t}</Tag>)}
      </div>

      <div style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-lg)', padding: 20 }}>
        {isMcp ? (
          <pre style={{ margin: 0, fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--color-text-secondary)', whiteSpace: 'pre-wrap' }}>{item.content}</pre>
        ) : (
          <div style={{ fontFamily: 'var(--font-sans)', fontSize: 14, lineHeight: 1.7, color: 'var(--color-text-secondary)' }}>
            {item.content.split('\n').map((line, i) => {
              if (line.startsWith('## ')) return <h3 key={i} style={{ fontSize: 16, color: 'var(--color-text)', margin: '14px 0 6px' }}>{line.slice(3)}</h3>;
              if (line.startsWith('# ')) return <h2 key={i} style={{ fontSize: 18, color: 'var(--color-text)', margin: '0 0 10px' }}>{line.slice(2)}</h2>;
              if (!line.trim()) return null;
              return <p key={i} style={{ margin: '0 0 8px' }}>{line}</p>;
            })}
          </div>
        )}
      </div>
    </div>
  );
};
