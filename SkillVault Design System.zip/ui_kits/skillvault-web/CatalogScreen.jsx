window.CatalogScreen = function CatalogScreen({ items, categories, onOpenItem, onRenameCategory, onMergeCategory }) {
  const { Input, Select, ItemCard, Icon, Button, StatusMessage } = window.SkillVaultDesignSystem_31593f;
  const [q, setQ] = React.useState('');
  const [type, setType] = React.useState('');
  const [categoryId, setCategoryId] = React.useState('');
  const [showCategories, setShowCategories] = React.useState(false);

  const filtered = items.filter(it => {
    if (q && !(it.name.toLowerCase().includes(q.toLowerCase()) || it.summary.toLowerCase().includes(q.toLowerCase()))) return false;
    if (type && it.type !== type) return false;
    if (categoryId && String(it.categoryId) !== categoryId) return false;
    return true;
  });

  const groups = {};
  filtered.forEach(it => {
    const cat = categories.find(c => c.id === it.categoryId);
    const name = cat ? cat.name : 'Sem categoria';
    (groups[name] = groups[name] || []).push(it);
  });
  const groupNames = Object.keys(groups).sort();

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: 16 }}>
        <div>
          <h1 style={{ margin: 0, fontFamily: 'var(--font-sans)', fontSize: 'var(--text-display)', fontWeight: 'var(--fw-display)', letterSpacing: 'var(--ls-display)', color: 'var(--color-text)' }}>Catálogo</h1>
          <p style={{ margin: '4px 0 0', fontFamily: 'var(--font-sans)', fontSize: 14, color: 'var(--color-text-tertiary)' }}>{filtered.length} de {items.length} itens</p>
        </div>
        <Button variant="ghost" iconLeft={<Icon name="folder-cog" size={15} />} onClick={() => setShowCategories(s => !s)}>Gerenciar categorias</Button>
      </div>

      <div style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap' }}>
        <Input placeholder="Buscar por nome ou resumo..." aria-label="Buscar" value={q} onChange={e => setQ(e.target.value)} style={{ width: 280 }} />
        <Select aria-label="Tipo" value={type} onChange={e => setType(e.target.value)} style={{ width: 160 }}>
          <option value="">Todos os tipos</option>
          <option value="skill">Skill</option>
          <option value="repo">Repo</option>
          <option value="mcp">MCP</option>
        </Select>
        <Select aria-label="Categoria" value={categoryId} onChange={e => setCategoryId(e.target.value)} style={{ width: 190 }}>
          <option value="">Todas as categorias</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
      </div>

      {showCategories && (
        <div style={{ background: 'var(--color-surface)', border: '1px solid var(--color-border)', borderRadius: 'var(--radius-lg)', padding: 16 }}>
          <h3 style={{ margin: '0 0 10px', fontFamily: 'var(--font-sans)', fontSize: 14, color: 'var(--color-text)' }}>Categorias</h3>
          <CategoryManagerInline categories={categories} onRename={onRenameCategory} onMerge={onMergeCategory} />
        </div>
      )}

      {groupNames.length === 0 && <StatusMessage kind="info">Nenhum item corresponde aos filtros.</StatusMessage>}

      {groupNames.map(name => (
        <section key={name} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <h2 style={{ margin: 0, fontFamily: 'var(--font-sans)', fontSize: 'var(--text-title)', fontWeight: 'var(--fw-title)', color: 'var(--color-text)' }}>{name}</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 14 }}>
            {groups[name].map(it => <ItemCard key={it.id} item={it} onOpen={() => onOpenItem(it.id)} />)}
          </div>
        </section>
      ))}
    </div>
  );
};

function CategoryManagerInline({ categories, onRename, onMerge }) {
  const { Input, Select, Button } = window.SkillVaultDesignSystem_31593f;
  const [renamingId, setRenamingId] = React.useState(null);
  const [renameValue, setRenameValue] = React.useState('');
  const [src, setSrc] = React.useState('');
  const [tgt, setTgt] = React.useState('');

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, fontFamily: 'var(--font-sans)' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {categories.map(c => (
          <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {renamingId === c.id ? (
              <>
                <Input value={renameValue} onChange={e => setRenameValue(e.target.value)} style={{ width: 200 }} />
                <Button size="sm" onClick={() => { onRename(c.id, renameValue); setRenamingId(null); }}>Salvar</Button>
              </>
            ) : (
              <>
                <span style={{ fontSize: 14, color: 'var(--color-text)', width: 200 }}>{c.name}</span>
                <Button size="sm" variant="ghost" onClick={() => { setRenamingId(c.id); setRenameValue(c.name); }}>Renomear</Button>
              </>
            )}
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'flex-end' }}>
        <Select label="Mesclar categoria" value={src} onChange={e => setSrc(e.target.value)} style={{ width: 170 }}>
          <option value="">Selecione a origem</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
        <Select label="Em" value={tgt} onChange={e => setTgt(e.target.value)} style={{ width: 170 }}>
          <option value="">Selecione o destino</option>
          {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </Select>
        <Button variant="secondary" disabled={!src || !tgt} onClick={() => { onMerge(Number(src), Number(tgt)); setSrc(''); setTgt(''); }}>Mesclar</Button>
      </div>
    </div>
  );
}
