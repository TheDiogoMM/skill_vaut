window.RecommendScreen = function RecommendScreen({ items }) {
  const { Textarea, Button, ItemCard, StatusMessage, Icon } = window.SkillVaultDesignSystem_31593f;
  const [idea, setIdea] = React.useState('');
  const [result, setResult] = React.useState(null);

  function submit(e) {
    e.preventDefault();
    if (!idea.trim()) return;
    const matched = items.filter(it => idea.toLowerCase().includes(it.tags[0]) || it.summary.toLowerCase().split(' ').some(w => idea.toLowerCase().includes(w) && w.length > 4));
    setResult({
      skill: matched.filter(i => i.type === 'skill'),
      repo: matched.filter(i => i.type === 'repo'),
      mcp: matched.filter(i => i.type === 'mcp')
    });
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20, maxWidth: 900 }}>
      <h1 style={{ margin: 0, fontFamily: 'var(--font-sans)', fontSize: 'var(--text-display)', fontWeight: 'var(--fw-display)', color: 'var(--color-text)' }}>Recomendar</h1>
      <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <Textarea label="Descreva a ideia do projeto" placeholder="Ex: preciso gerar relatórios em PDF a partir de dados de um banco Postgres" value={idea} onChange={e => setIdea(e.target.value)} />
        <div><Button iconLeft={<Icon name="wand-2" size={14} />}>Recomendar do catálogo</Button></div>
      </form>
      {result && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {['skill', 'repo', 'mcp'].map(t => (
            <div key={t} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <h3 style={{ margin: 0, fontFamily: 'var(--font-sans)', fontSize: 13, textTransform: 'uppercase', letterSpacing: '.04em', color: 'var(--color-text-tertiary)' }}>{t === 'skill' ? 'Skills' : t === 'repo' ? 'Repos' : 'MCPs'}</h3>
              {result[t].length === 0 && <StatusMessage kind="info">Nenhum {t} do catálogo cobre essa necessidade.</StatusMessage>}
              {result[t].map(it => <ItemCard key={it.id} item={it} onOpen={() => {}} />)}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
