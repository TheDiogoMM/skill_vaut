# SkillVault Design System

SkillVault is a personal, single-user library for cataloging **skills, code repositories, and MCPs (Model Context Protocol servers)**, built to run locally and feed a searchable index that Claude Code can consume as project context. This design system gives it a real visual identity — the original codebase shipped only unstyled semantic HTML (`apps/web/src/theme.css`: raw dark-mode CSS variables, no component library, no icons, no logo).

## Sources

- GitHub repo: [TheDiogoMM/skill_vaut](https://github.com/TheDiogoMM/skill_vaut) — full-stack TypeScript monorepo (Fastify + better-sqlite3 backend, React + Vite frontend). Explore it further for the real ingestion pipelines, API contracts, and test suites this design system was built to visually match.
- `docs/superpowers/specs/2026-07-16-skillvault-design.md` (in that repo) — the product spec: architecture, LLM-enrichment fallback chain, data model, REST API, and the full frontend route list (Catálogo, Detalhe, Adicionar, Recomendar, Categorias).
- `PROJECT_CONTEXT.md` (in that repo) — continuity doc with what's built vs. planned.

The reader may not have access to this repo — treat the above as reference, not a dependency.

## Product context

Single product, one surface: a **desktop-first local web app** (PWA, installable, offline catalog view). No mobile app, no marketing site. Portuguese (pt-BR) throughout — this is a personal tool for one Portuguese-speaking developer, not a public/localized product.

Three content types flow through the same catalog: **Skill** (a `SKILL.md` + assets bundle), **Repo** (a cloned git repository), **MCP** (a Claude Code tool-server config). Each item gets an LLM-generated summary/utility/category/tags (fallback chain: local Ollama → Gemini free tier → manual entry), and the whole catalog regenerates an `index.json`/`INDEX.md` on every change for Claude Code to read.

## Index

- `styles.css` — root stylesheet, imports everything below.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `effects.css` (radius/shadow/motion), `fonts.css` (Google Fonts import).
- `base.css` — resets and global element defaults.
- `components/` — reusable primitives, grouped by concern:
  - `core/` — `Icon`, `Button`, `IconButton`
  - `forms/` — `Input`, `Select`, `Textarea`, `Tabs`
  - `data-display/` — `TypeBadge`, `Tag`, `ItemCard`
  - `feedback/` — `StatusMessage`
  - `navigation/` — `Sidebar`
- `ui_kits/skillvault-web/` — click-through recreation of the app: Catálogo, Detalhe do item, Adicionar (repo/skill/mcp), Recomendar.
- `guidelines/` — foundation specimen cards (colors, type, spacing, brand).
- `assets/` — logo (full lockup, symbol, wordmark), favicon — see Logo section below.
- `SKILL.md` — portable skill definition for use in Claude Code.

## Components

- **Core**: `Icon`, `Button`, `IconButton`
- **Forms**: `Input`, `Select`, `Textarea`, `Tabs`
- **Data display**: `TypeBadge`, `Tag`, `ItemCard`
- **Feedback**: `StatusMessage`
- **Navigation**: `Sidebar`

## Intentional additions

No component library existed in the source repo (only unstyled native `<input>`/`<select>`/`<button>` elements) and no Figma file was provided, so per design-system convention this is a **from-scratch build**: a standard component set was authored, sized specifically to what the app's own screens need (no unused primitives like Dialog, Toast, or Avatar — the product has none of these; status messages are always inline, never toasts).

## Content fundamentals

- **Language & person**: Portuguese (pt-BR), consistently across every label, button, and error message in the source (`Adicionar repositório`, `Copiar caminho`, `Salvo!`). Address is impersonal/instructional — labels name the field or action directly ("Nome", "URL do repositório"), never "seu/sua". No marketing voice; this is a personal tool, not a product with an audience to persuade.
- **Casing**: sentence case everywhere — "Adicionar item", "Nenhum item cadastrado ainda." Never title case, never all-caps except small uppercase tags like category eyebrows in this design system's own additions.
- **Tone**: dry, functional, technical. Copy states what happened or what to do, nothing more: `"Não foi possível carregar o catálogo."`, `"Selecione a origem"`, `"O config precisa ser um JSON válido."` No enthusiasm, no exclamation marks except the two genuine confirmations in the source (`"Salvo!"`, `"Copiado!"`) — reserve `!` for instant success feedback only, never for headings or CTAs.
- **Emoji**: none, anywhere in the source. Do not introduce any.
- **Errors**: specific and calm, always tied to `role="alert"` — e.g. `"O config precisa ser um JSON válido."` rather than a generic "Something went wrong."
- **Vibe**: a developer's personal tool room, not a SaaS product — no onboarding copy, no empty-state illustrations with encouraging taglines, just a plain sentence ("Nenhum item cadastrado ainda.").

## Visual foundations

- **Color**: dark mode is the default and primary experience (`color-scheme: dark`), with a light theme as a secondary toggle — both are first-class, not an afterthought. Base neutrals are a desaturated blue-gray scale (`--gray-900` `#0f1115` background up to `--gray-50` text) lifted directly from the source `theme.css`. One accent color, a periwinkle blue (`--color-accent` `#6d8dff` dark / `#3355dd` light), used for links, primary buttons, and focus rings — never for anything else. Danger is a standard red; success a muted green. The three catalog item types (Skill/Repo/MCP) each get a dedicated identity color (violet/green/amber) used consistently for badges, icons, and borders — this is the one place multiple hues coexist deliberately, as a categorization device, not decoration.
- **Type**: two families. Inter (UI, headings, body) and JetBrains Mono (paths, commands, JSON config, tags) — the mono face is a deliberate signal: "this is machine-readable/literal," used for `~/skillvault/...` paths and catalog tags, never for prose. No serif anywhere; this is a technical tool, not an editorial product.
- **Spacing**: 4px base unit (4/8/12/16/24/32/48). Cards use 16px internal padding, 8px gaps between stacked text elements — tight and information-dense, consistent with a personal cataloging tool rather than a marketing page.
- **Backgrounds**: flat solid surfaces only. No gradients, no photography, no illustration, no patterns/textures. Three-level elevation via `background` shift alone (bg → surface → surface-raised), not shadow-driven — shadows are reserved for genuinely floating elements (dropdowns, the recommend result panel).
- **Animation**: minimal and fast. 120–180ms transitions on hover/press only (`--duration-fast`/`--duration-base`, ease-out curve). No entrance animations, no bounces, no page transitions — a tool you use all day should feel instant, not delightful.
- **Hover states**: background lightens one surface step (`--color-surface` → `--color-surface-hover`); links darken/lighten the accent slightly (`--color-accent-hover`). Never opacity-only.
- **Press states**: buttons scale to 97% (`transform: scale(.97)`) plus a step further toward `--color-accent-active`. No color-only or shadow-only presses.
- **Borders**: 1px, `--color-border`, on every surface boundary (cards, inputs, dividers) — this is a bordered design system, not a shadow-only one. Shadows are secondary/rare.
- **Radius**: 8px is the base (`--radius-md`, matches the source exactly — do not round to a different framework default), 6px for tight controls, 12–16px for cards/panels, full pill radius for tags and type badges.
- **Cards**: `--color-surface` fill, 1px `--color-border`, `--radius-lg` (12px), no shadow at rest — hover only strengthens the border (`--color-border-strong`), never adds a shadow or lift/scale. This keeps dense grids of 20+ catalog cards calm.
- **Layout**: desktop-first, explicit product decision — fixed 248px left sidebar (nav + theme toggle), content area with generous 32px padding. Collapses to a single column under 720px (sidebar becomes a top bar in the real app) as a secondary, not primary, concern.
- **Transparency/blur**: none used. Flat, opaque surfaces throughout.
- **Imagery**: none in the product — it's data/text only, no photography or illustration anywhere in the source or this system.

## Iconography

The source codebase has **no icon system at all** — no icon font, no SVG sprite, no PNG icons, no emoji, no unicode glyphs used as icons (verified across every `.tsx` file: buttons and nav are plain text). This design system introduces **Lucide** (outline, 2px stroke, CDN-loaded via `unpkg.com/lucide`) as the closest CDN-available match for a technical/developer-tool product — flagging this as a substitution, not something recovered from source. Icons load through the `Icon` component (`components/core/Icon`), which injects the Lucide script once and re-scans `data-lucide` elements; usage is documented in `Icon.prompt.md`. Icons are used sparingly: type identity (sparkles/git-branch/plug for Skill/Repo/MCP), a handful of toolbar actions (search, copy, theme toggle), and nothing decorative.

## Logo

The user supplied a flat-design lockup (`uploads/SkillVault_logo_vector_flat_design_202607191350.jpeg`): a safe/vault glyph (rounded-square body, dial, code-bracket and circuit-trace details, blue→cyan gradient) paired with a "SkillVault" wordmark ("Skill" in solid blue, "Vault" in white) and a cyan tagline. It was separated into three assets in `assets/` (background chroma-keyed to transparent):

- `assets/logo-full.png` — primary lockup: symbol + wordmark + tagline. Use wherever there's room (headers, cover slides, marketing contexts).
- `assets/logo-symbol.png` — symbol only, for the sidebar nav, favicon source, and any compact/square placement.
- `assets/logo-wordmark.png` — wordmark + tagline only, no symbol (use only when the symbol appears elsewhere on the same view).
- `assets/favicon.png` (512×512) / `assets/favicon-64.png` — symbol cropped square for browser tab / app icon use.

See `guidelines/brand-logo.card.html` and `guidelines/brand-favicon.card.html`.

## Fonts — substitution flag

The source app used only a system font stack (`-apple-system, 'Segoe UI', Roboto, sans-serif`) — no branded typeface was ever specified. **Inter** (UI/body) and **JetBrains Mono** (code/paths) were added as the nearest well-established developer-tool pairing and are loaded from Google Fonts CDN in `tokens/fonts.css`. If you have specific typeface preferences, let me know and I'll swap them.
