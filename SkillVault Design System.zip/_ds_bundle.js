/* @ds-bundle: {"format":4,"namespace":"SkillVaultDesignSystem_31593f","components":[{"name":"Button","sourcePath":"components/core/Button/Button.jsx"},{"name":"Icon","sourcePath":"components/core/Icon/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton/IconButton.jsx"},{"name":"ItemCard","sourcePath":"components/data-display/ItemCard/ItemCard.jsx"},{"name":"Tag","sourcePath":"components/data-display/Tag/Tag.jsx"},{"name":"TypeBadge","sourcePath":"components/data-display/TypeBadge/TypeBadge.jsx"},{"name":"StatusMessage","sourcePath":"components/feedback/StatusMessage/StatusMessage.jsx"},{"name":"Input","sourcePath":"components/forms/Input/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select/Select.jsx"},{"name":"Tabs","sourcePath":"components/forms/Tabs/Tabs.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea/Textarea.jsx"},{"name":"Sidebar","sourcePath":"components/navigation/Sidebar/Sidebar.jsx"}],"sourceHashes":{"components/core/Button/Button.jsx":"6c14c135ab3c","components/core/Icon/Icon.jsx":"7ae684b80c4c","components/core/IconButton/IconButton.jsx":"ed0b143d764d","components/data-display/ItemCard/ItemCard.jsx":"dcb1d8059310","components/data-display/Tag/Tag.jsx":"c92dfe530af5","components/data-display/TypeBadge/TypeBadge.jsx":"9204ba217720","components/feedback/StatusMessage/StatusMessage.jsx":"4c8bb5caa43d","components/forms/Input/Input.jsx":"910009ce4cc6","components/forms/Select/Select.jsx":"4eb092087615","components/forms/Tabs/Tabs.jsx":"3c8d7d2927e9","components/forms/Textarea/Textarea.jsx":"822ffbddbbe1","components/navigation/Sidebar/Sidebar.jsx":"5e0d215f964a","ui_kits/skillvault-web/AddScreen.jsx":"96fa37a36208","ui_kits/skillvault-web/App.jsx":"c7a46de9c8f7","ui_kits/skillvault-web/CatalogScreen.jsx":"0df5c4ded389","ui_kits/skillvault-web/ItemDetailScreen.jsx":"525254f0c01f","ui_kits/skillvault-web/RecommendScreen.jsx":"38d5bdabd2ca","ui_kits/skillvault-web/mock-data.js":"2c4a12d7c7a7"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SkillVaultDesignSystem_31593f = window.SkillVaultDesignSystem_31593f || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button/Button.jsx
try { (() => {
function Button({
  variant = 'primary',
  size = 'md',
  iconLeft,
  iconRight,
  disabled,
  children,
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '6px 10px',
      fontSize: 13
    },
    md: {
      padding: '9px 14px',
      fontSize: 14
    },
    lg: {
      padding: '11px 18px',
      fontSize: 15
    }
  };
  const variants = {
    primary: {
      background: 'var(--color-accent)',
      color: 'var(--color-text-on-accent)',
      border: '1px solid transparent'
    },
    secondary: {
      background: 'var(--color-surface-hover)',
      color: 'var(--color-text)',
      border: '1px solid var(--color-border-strong)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--color-text-secondary)',
      border: '1px solid transparent'
    },
    danger: {
      background: 'var(--color-danger)',
      color: '#fff',
      border: '1px solid transparent'
    }
  };
  const hoverBg = {
    primary: 'var(--color-accent-hover)',
    secondary: 'var(--color-surface-raised)',
    ghost: 'var(--color-surface-hover)',
    danger: 'var(--color-danger-hover)'
  };
  return React.createElement('button', {
    type: 'button',
    disabled,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 6,
      fontFamily: 'var(--font-sans)',
      fontWeight: 600,
      borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'background var(--duration-fast) var(--ease-out), transform var(--duration-fast)',
      ...sizes[size],
      ...variants[variant],
      ...style
    },
    onMouseEnter: e => !disabled && (e.currentTarget.style.background = hoverBg[variant]),
    onMouseLeave: e => !disabled && (e.currentTarget.style.background = variants[variant].background),
    onMouseDown: e => !disabled && (e.currentTarget.style.transform = 'scale(.97)'),
    onMouseUp: e => !disabled && (e.currentTarget.style.transform = 'scale(1)'),
    ...rest
  }, iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon/Icon.jsx
try { (() => {
function Icon({
  name,
  size = 16,
  strokeWidth = 2,
  style,
  ...rest
}) {
  React.useEffect(() => {
    if (window.__lucideLoading || window.lucide) {
      window.lucide && window.lucide.createIcons();
      return;
    }
    window.__lucideLoading = true;
    const s = document.createElement('script');
    s.src = 'https://unpkg.com/lucide@latest/dist/umd/lucide.js';
    s.onload = () => window.lucide && window.lucide.createIcons();
    document.head.appendChild(s);
  }, [name]);
  return React.createElement('i', {
    'data-lucide': name,
    style: {
      width: size,
      height: size,
      display: 'inline-flex',
      flexShrink: 0,
      ...style
    },
    'data-stroke-width': strokeWidth,
    ...rest
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton/IconButton.jsx
try { (() => {
function IconButton({
  name,
  size = 18,
  label,
  active,
  style,
  ...rest
}) {
  return React.createElement('button', {
    type: 'button',
    'aria-label': label,
    title: label,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 32,
      height: 32,
      borderRadius: 'var(--radius-md)',
      background: active ? 'var(--color-surface-hover)' : 'transparent',
      border: '1px solid transparent',
      color: active ? 'var(--color-text)' : 'var(--color-text-secondary)',
      cursor: 'pointer',
      transition: 'background var(--duration-fast) var(--ease-out)',
      ...style
    },
    onMouseEnter: e => e.currentTarget.style.background = 'var(--color-surface-hover)',
    onMouseLeave: e => e.currentTarget.style.background = active ? 'var(--color-surface-hover)' : 'transparent',
    ...rest
  }, React.createElement(__ds_scope.Icon, {
    name,
    size
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Tag/Tag.jsx
try { (() => {
function Tag({
  children,
  onRemove,
  style
}) {
  return React.createElement('span', {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      padding: '3px 9px',
      background: 'var(--color-surface-hover)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-full)',
      color: 'var(--color-text-secondary)',
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      ...style
    }
  }, children, onRemove && React.createElement('button', {
    type: 'button',
    onClick: onRemove,
    'aria-label': 'Remover tag',
    style: {
      border: 'none',
      background: 'none',
      color: 'inherit',
      cursor: 'pointer',
      padding: 0,
      display: 'flex',
      opacity: .7
    }
  }, '\u00d7'));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Tag/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data-display/TypeBadge/TypeBadge.jsx
try { (() => {
const CONFIG = {
  skill: {
    label: 'Skill',
    color: 'var(--color-type-skill)',
    bg: 'var(--color-type-skill-bg)',
    icon: 'sparkles'
  },
  repo: {
    label: 'Repo',
    color: 'var(--color-type-repo)',
    bg: 'var(--color-type-repo-bg)',
    icon: 'git-branch'
  },
  mcp: {
    label: 'MCP',
    color: 'var(--color-type-mcp)',
    bg: 'var(--color-type-mcp-bg)',
    icon: 'plug'
  }
};
function TypeBadge({
  type,
  size = 'md'
}) {
  const c = CONFIG[type] || CONFIG.skill;
  const pad = size === 'sm' ? '3px 8px' : '4px 10px';
  const font = size === 'sm' ? 11 : 12;
  return React.createElement('span', {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      padding: pad,
      borderRadius: 'var(--radius-full)',
      background: c.bg,
      color: c.color,
      border: `1px solid color-mix(in oklch, ${c.color} 45%, transparent)`,
      fontFamily: 'var(--font-sans)',
      fontSize: font,
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '.04em'
    }
  }, React.createElement(__ds_scope.Icon, {
    name: c.icon,
    size: font + 2
  }), c.label);
}
Object.assign(__ds_scope, { TypeBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/TypeBadge/TypeBadge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/ItemCard/ItemCard.jsx
try { (() => {
function ItemCard({
  item,
  onOpen
}) {
  return React.createElement('div', {
    role: 'button',
    tabIndex: 0,
    onClick: onOpen,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      padding: 'var(--space-4)',
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-lg)',
      cursor: 'pointer',
      fontFamily: 'var(--font-sans)',
      transition: 'border-color var(--duration-fast) var(--ease-out), transform var(--duration-fast)'
    },
    onMouseEnter: e => e.currentTarget.style.borderColor = 'var(--color-border-strong)',
    onMouseLeave: e => e.currentTarget.style.borderColor = 'var(--color-border)'
  }, React.createElement('div', {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      gap: 8
    }
  }, React.createElement('span', {
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: 'var(--color-text)'
    }
  }, item.name), React.createElement(__ds_scope.TypeBadge, {
    type: item.type,
    size: 'sm'
  })), item.summary && React.createElement('p', {
    style: {
      margin: 0,
      fontSize: 13,
      color: 'var(--color-text-secondary)',
      lineHeight: 1.5
    }
  }, item.summary), item.utility && React.createElement('p', {
    style: {
      margin: 0,
      fontSize: 12,
      color: 'var(--color-text-tertiary)'
    }
  }, item.utility), item.tags && item.tags.length > 0 && React.createElement('div', {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, item.tags.map(t => React.createElement(__ds_scope.Tag, {
    key: t
  }, t))), item.localPath && React.createElement('code', {
    style: {
      fontSize: 11,
      color: 'var(--color-text-tertiary)',
      fontFamily: 'var(--font-mono)'
    }
  }, item.localPath));
}
Object.assign(__ds_scope, { ItemCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/ItemCard/ItemCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusMessage/StatusMessage.jsx
try { (() => {
const KIND = {
  success: {
    color: 'var(--color-success)',
    icon: 'check-circle-2'
  },
  error: {
    color: 'var(--color-danger)',
    icon: 'alert-circle'
  },
  info: {
    color: 'var(--color-text-secondary)',
    icon: 'info'
  }
};
function StatusMessage({
  kind = 'info',
  children
}) {
  const c = KIND[kind] || KIND.info;
  return React.createElement('p', {
    role: kind === 'error' ? 'alert' : 'status',
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      color: c.color
    }
  }, React.createElement(__ds_scope.Icon, {
    name: c.icon,
    size: 15
  }), children);
}
Object.assign(__ds_scope, { StatusMessage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusMessage/StatusMessage.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input/Input.jsx
try { (() => {
function Input({
  label,
  hint,
  error,
  id,
  style,
  ...rest
}) {
  const inputId = id || React.useId();
  return React.createElement('div', {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)'
    }
  }, label && React.createElement('label', {
    htmlFor: inputId,
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--color-text-secondary)'
    }
  }, label), React.createElement('input', {
    id: inputId,
    style: {
      background: 'var(--color-surface)',
      color: 'var(--color-text)',
      border: `1px solid ${error ? 'var(--color-danger)' : 'var(--color-border)'}`,
      borderRadius: 'var(--radius-md)',
      padding: '9px 12px',
      fontSize: 14,
      fontFamily: 'inherit',
      outline: 'none',
      transition: 'border-color var(--duration-fast)',
      ...style
    },
    onFocus: e => e.currentTarget.style.boxShadow = 'var(--focus-ring)',
    onBlur: e => e.currentTarget.style.boxShadow = 'none',
    ...rest
  }), hint && !error && React.createElement('span', {
    style: {
      fontSize: 12,
      color: 'var(--color-text-tertiary)'
    }
  }, hint), error && React.createElement('span', {
    role: 'alert',
    style: {
      fontSize: 12,
      color: 'var(--color-danger)'
    }
  }, error));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select/Select.jsx
try { (() => {
function Select({
  label,
  id,
  children,
  style,
  ...rest
}) {
  const selId = id || React.useId();
  return React.createElement('div', {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)'
    }
  }, label && React.createElement('label', {
    htmlFor: selId,
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--color-text-secondary)'
    }
  }, label), React.createElement('select', {
    id: selId,
    style: {
      background: 'var(--color-surface)',
      color: 'var(--color-text)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-md)',
      padding: '9px 12px',
      fontSize: 14,
      fontFamily: 'inherit',
      outline: 'none',
      ...style
    },
    onFocus: e => e.currentTarget.style.boxShadow = 'var(--focus-ring)',
    onBlur: e => e.currentTarget.style.boxShadow = 'none',
    ...rest
  }, children));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Tabs/Tabs.jsx
try { (() => {
function Tabs({
  tabs,
  value,
  onChange
}) {
  return React.createElement('div', {
    role: 'tablist',
    style: {
      display: 'inline-flex',
      gap: 2,
      background: 'var(--color-bg-inset)',
      padding: 3,
      borderRadius: 'var(--radius-md)',
      border: '1px solid var(--color-border)'
    }
  }, tabs.map(t => React.createElement('button', {
    key: t.value,
    type: 'button',
    role: 'tab',
    'aria-selected': value === t.value,
    onClick: () => onChange(t.value),
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      fontWeight: 600,
      padding: '7px 14px',
      borderRadius: 'var(--radius-sm)',
      border: 'none',
      cursor: 'pointer',
      background: value === t.value ? 'var(--color-surface)' : 'transparent',
      color: value === t.value ? 'var(--color-text)' : 'var(--color-text-tertiary)',
      boxShadow: value === t.value ? 'var(--shadow-sm)' : 'none',
      transition: 'all var(--duration-fast) var(--ease-out)'
    }
  }, t.label)));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Tabs/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea/Textarea.jsx
try { (() => {
function Textarea({
  label,
  id,
  mono,
  style,
  ...rest
}) {
  const taId = id || React.useId();
  return React.createElement('div', {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)'
    }
  }, label && React.createElement('label', {
    htmlFor: taId,
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--color-text-secondary)'
    }
  }, label), React.createElement('textarea', {
    id: taId,
    rows: 6,
    style: {
      background: 'var(--color-bg-inset)',
      color: 'var(--color-text)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-md)',
      padding: '10px 12px',
      fontSize: mono ? 13 : 14,
      lineHeight: 1.5,
      fontFamily: mono ? 'var(--font-mono)' : 'inherit',
      outline: 'none',
      resize: 'vertical',
      ...style
    },
    onFocus: e => e.currentTarget.style.boxShadow = 'var(--focus-ring)',
    onBlur: e => e.currentTarget.style.boxShadow = 'none',
    ...rest
  }));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Sidebar/Sidebar.jsx
try { (() => {
const LOGO_SYMBOL_SRC = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABECAYAAAAx+DPIAAAQAElEQVR4Aex6eXwURdr/U9U992RyQA6OQBISjoDI4a4EBeO9kkVAhXBIEEFg3fVYdvVdVpaNoruuqLgeKCAICBiIKOFWlkPQDfeRQLhykQBJSDLJTOae7q7fU53MZBJAYX0/v3/e7fRTz/N8n6eeqnq6urq6JxT+jx//TcD/8QkA/50B/50B18tAeroYfveLSeET1yTpJ355XQpvg29p8eE8QLxeQOac65xCZa6HUsDGeSi19+G2ALYF+8l1TgHsy6S48Z8lQNexhusNLxS75hYwpz7cV9dx1gzZFHdBZroSqpASogglhAklABrkSMj9RIO6FnVOiioDsBJCoISAgoQ4QY5EGXKmLQGmQVxRObToHGOIcw5YDwD9kBPG0I/7ckJM9RGxPa5zEtEuqvH8vF21DsZniCF5qeGMccA9fzZlbe+PAyZI1z1pKKrv+eu75YSMj0Af9ZES3Z8Sj9VHrWcaaf2pOlJbUE9rTzbQugKrUHcK+SmrWFeIcqGV1haiXIB00kqvnrDS2oIGoa7AitxKrxagb2G9UF9YL9adslL0xfpW0VpoFetP1SOOvLABZTWWUFfYwInWYay6AtXGfYS6QrSfQipsVPX60+h3ul6oLawntSfqaO3JelqHbViLGkRbsdcnmPVyZM+5CoOlmsyveBJChxqU2ySA9BkzCyIShmnAc5WCfK/eV/2Atvb0CMF64tfi1YIMseYEl0do6wpGaGsLMnT1hSOotRAxLp8aoas/hfLxEdhBVdZzXfU5xn0zdOirRxKQdHWFI7B+hurTLI8Q6goykEbo6gpGcJtYX5jB20IsQ289NYKTtr7oEbRnIKFemIExMwTsHxLy4xmaxtMj9LbzD2iY/16g0ktMkX6pJcoa04S1scFRhwjBBHQZ/e5cjU4/nigStdhIomP1yL21W+fttx7/It9+dMNBewGnrw5w2Xps3QFO9UdzDto5oc5lTtxuD9VR5hi3BYjXCcicB/w558RjcwrInHM/TtZja9S2uZ3rnHj8AFkPrjlQ+8OS7xtXj9nrdTkWgixl4yzoC6V7J4SMOygGE9BgSNL4qVHQVu7efWXzSFfQo0XQPpDRZ/iW/D7Dd+b3GYJ8yJbvkF+PAvYf4cEYP+KjtnE9O28zBMdYvE+DPl2fDL16hbV0t5nljpMN3ssugflkbVL6wmawbRlMgEJRpAJISfe1zVTv3h1SztsmWNLuPe3sEFXkCutQ5IuKKvJERhe5wzsWeSKiVXJzjpgnKrLIg3avSpFFXqzjQfIi7u0Qqdb1mTuoPp7IKKwbWeSJjChyR0QUeSJQRuK+HvTn7XC5maKKOOftcn8e19cxssgXFlXksmA/unQ72GnOgtf6lLq7hw7Rcfabap/L3ugl4aFwUMZRB2QRgAgAYEJqPeMW5TwvCcLKqKdnESm2MyixnQDiOgPp0hUpHlinLqCo1BkY4kpMJ5Bj40CO64S+nUFGnan1Oqu6hLiEMTiucM7rxHYBhXOV4kBGXME6PAZDzmVFxTphG10BOnUGwDgQ1wX1LuCPiQO5d78o/T0PvugD5ZPel1iHwAiI5JEYFWTGL3AADOEhCQhBW8SHT1yaZemW+IJGkfCU0/SyL80gISE3Mn+aSfan6RUpzYBkVNCOZGBSmhF1g2rzo82v1tMrnPvTOG5oqW/AGEYklfswjirLWAflFn8T50GSsD3erpRmlDCW35dm9MtpeuwTleQ0RWEfSUB/VfXn3+W2DAGAEQqM4ZNYCUKhQjABVJEAFBltTqTm83JUdDyIuvCy6ZOWFKeEHziY0uHADwFKbJY59r9CqR3U+O1j8fauh3G8mZr7dQb7l1RdXmHxuqDfvDfubR4BlkRhVJEZAz421NudwQTg6DFZba0UFBDwruiY2ntJW0uz9siFC7q0E+UD+xc3xTQjAMMvOwfeV9rQPaD//+RVJ44rXnsD84ja1mYJUxTcmYHCVKx90ZoAvEcIkDZ2LVVAh5Cg1fnbGFoUt9/0kldmx0jVxSdbIHCXFB9zUrruthLrbQHs5/L+FU39Blz1pLTEoVGz/vDwoAvVQ1r0IGMiwd4CXnM5iKkXXh27WrTiLVJrAvDFEOdJC9zMTAJsNDB5JpPY5WakbWnT6uc7RfGQcuLEzoDFfeZUNnO67mRafes0DBj/A96vwtPDJ4iLvT6WplZPTtb4FTbHRXVLbi+t+6WKtRQCwwP4JQ8ZLM5gHBoQwnPT4hjCQhIA6ATqYUkdG6Xv98TSww9OmXEiY9rdjfkVi8wDJ60Nv2PsNNWhpfBqtaA1hxUXPvdkYQsEsbGxubSxDtwB4GfwwUeYRhKUbZLXf9lfemm7Gqq42Oeturywcd/uWFHQrxsaerv5ZCbLMs75kASAgOOneHv/RAIUkHCxbJ46vr5jzaTfxOly30nTldQJk/19Jo3z9Z00QdPriYfUTmCRvoeJiiiyaMXbZnk9tHKpVPLv/Y2e+joLjB0bcjNipVs8m6KaPD6fZLM9Pe3p4uEptS3VmW/zuryrSxb9pfrwgVjKX5oCBoLPAZwE115sBujX4tWW0YBKMU8ESEDFZDDUlEqiSAc0klOi+DQJGlGoTHLsE4lYaSb6V1ENnk2FRy8aUvq8qWXwYtdxM4YGDf+BUDZl9DRmb+zWefniZYOv2DsGQiRfqLckf7m5n2nI0MtXAJICOOc4eKa0v5cZAJ7cfA0FEwDAp0lA1aMqAgiaTzzrH0+LcJ61E1kGUFrXwqqHhj8hyFI3m0jbJCB5zPiuQkPD864rl1ZfmjP32DUt3gLg3797Ve2SRfOarlTdV7/v+9ciH3ggnM+8GMkznzAYRqk4vrRHVEVoSMYwBaEAl5XrgdwAEBixKhH1KuNOEMdP+KOEtsxg2QdU9gAgb64G4Dp3/IpP8kEd3mMBjPOUu9J1sck9OxtSB5RC8UE7x34GKY4jJ3Nsu3f83llw8pDgNioAe0GUpaN+hT1ztrP2KIQcjDCCV6ltBvC6EUpvNAGgNQEYmqgThW+E8EMKjxUMjhaGMRSkIAZg9PnBXnzmvqgpv3s8AB/5bu8nzs5dQac+fwLoz+AHt9vrd2/Oqb1w7PO6HzY17b33Xmlfv+6rSruZjlwTVSY4VBw/PvhDbYzh4Hj/Q8EWuTUBCLCgE67hCl51RdbA5G9MTNQTwH0CtEkKAKNySkTX7mEdXpmPm3NQj8TZrwzylZV8Xzrmvn0qEFrgp7bOIxcbYfIqUzN9Y4rlcupPLJZ790qQm4vXMjTYdWRCGaECIwJOhBAzIQTwEoYgrWIwAZgjRJtLwNkOCsqKlI17f0eDZVAkoToALd4b6BU4jyXHFBf27mi+0DPygwB2KN5gPvfA4GH+E4dPBLDYyQtMHZ/4ON0o3DvHo4FKo8/oMPrNDpPf7fD7NQ5L1wFLzU9uT4+8c/oNv9wEYv0YV3CNUnD32tYH84YTV8EUtMWbtWACeD2eJw7TxjMSs54rUawXiln9hQqoL6qEujOXobEcF13ucfNk6ZoW5ZB7vuYTwvewmAGvSZrIKOKskhlg05Ib/AoBKWZQlgKwR4rqux4/tj7wU9Gjnnu5a9wLc1/q9PL8Pm18GTT/kVBUAD52StuAEDiwF80iVSW1AFfZ3nqp/NupUvmOqVCxewor2zUFLv1rirfs+4+bvW+uDEu+J026+39WMaqfLUmKT7CXfSwS93ix8dwEIJT3a5fGWz+eMmm8vqkY5PDEXj6FfKwfn5t+oxZMI0bdFjlr9kptxpi3xIlPLzeMnvhCwFc7YBBl4RZqdjsCEFBKcOiMAk94EG0V0NCq8B6pWvF2r3R+1/6e29YN6b5l9bKYTxedcBbt2NV0dtt51X5zhagM/M1fGdVkiMR3VvG5e+sbC/7HmjNlne37D78EEZ8whqgSa95v1znWjFwnSvU9qM8xnjBIxjt5fdiEL3tfr5mkD1d/ozTa7qn+8gunt+ryHR2z3379kcMXSoafuFji6po0x2+ykPrS4tGBugrBFZBiVEICUBsekgCchDiDQq1uUR/pETRJzg2r4kLxn5KTH3lOZx6b85FCNQ9r5Sar/fORfTybnymr+2F5E+BCaHp0aQwjAt51TJ/w1GfqwnJ1a3ap46sn1ylMmqEAjRSZ/wzAWJy/bVvzgthJ16nTIZ1G0z08tU+eLirCfDYyJqnCHJnkJcTg27i2ovbrnOD+Q/ZLMsh+md7gqRRMwLXDB3XS4PYItF07XfONsG232mqNSvTjxN/0NPXawKZQ/ITUbI8auzzVpLn/Ba05qoqvyiLzZjm9uneiR775SLMHADn60Q5Bcu3yCOEQkXFn8C0TWg7a1LDPXlefZujZs06qqn5cLi+zRuTv3aHdvmFb44LsWVd/P7279bNFlS3uIMj+0wbq3WyUG3YEsFAeTABeDoB2z3ncWgMwAsRg4vkJrXdjefBgjdvYPU4ydhapu2oFQPPjKyJz2e2yoPsMolLfVmQ/US4fcklNNX4nNT/r18dti7pzyh94UHfJvkoduNYTUBrk8KRrvkNcef0vYwilK7UJyRITNF9VvTv/5eOTRz1y/rmpGc7F767iMULJV7G/yLr5jzOv5jwVTHKoPZgASlEkSCFWhjIhBPy1VToUb+qMix7ZxUA8swRceiC671JQn99jBclPh0vE+EuoPX1SlGxjoPLgE4Kj4jGTt+pbWRMJvi73vBFowJq/OEcBekUGHTV2u3NwAOfcnrvMSrZsmM2O54+Rvvnqec/GnGUcb0/Rz+4xh03eutE4MW+jJfOLjeaxy6Pb+3C9zYhxrBxrJW7F9UPTrZO3Ffxxydch1ejTRaeI3nowNF1UnePG3t9Lq9W/LggiiJbOf6jfMHOj9/zm7U27Xt9ikqoyZVkuBH2M1ph03yy1wpWjLpFIskIEMSzxjtc4Zo6/o585ceDwsPhBw6zLPk9qXP6Fp/6TNV2N8QPvMHQeMNScfEe6uceQTEviXb8LS0yb5nG6LzCgo7SKd5QC4igLUQp5nPbEh6hiQUHVWgoF7wDcHXoKiywtyE8yH3rgygtS40VwX2neC3kNnURJDLMQeyWI9rImdAme5RuzGw3g9IPiI2EJA6cGDHrFBYQQECKTIgAP5b43X5KHvfWdNGz+Pnb3a4flu17dCcPmHWB3Zx+Ge179Qf7lX/bId87N8Q995QP57uxPFUWME6jwbWPOOHwQ6r+2CR1//JchbAMIL9oRYQCGcIO/HXxj1ecDIktAtQbQhEU2+zmvIobPZgOOxYKftZvRYCkRHWAzILvtxwOgjDtRwnABdzfylxMghB0nlOSBIOYRqskjRMgDpiDJeUSR80Dm5EPuz2OKP08r20BiLMY88asnZFGMpzgjA7FDefDCN28heTdazYTPACAg29yaVvTHJZ2tWKGuqx4ShgONGag6k/qDVnDUfCdpIoAZInGas2CujRO3jvJrLJ2ZoFG8F4/NVStgIWFSiOKTpIayRaiCc8WD77lWgTf43gAAEABJREFUPDDa/fnDo11rfjXavTZjtDtnDNJjo13rHhvtDlDOqNHuNb8ebXZf/BttKh8AVLOe2sq706qDb/I47SmYgGZD2wQAWgleG9KlN16+Zo+fKsXqkkqF6t/zET24ofmXKmej53m/qWs84FPGx7RTTZmbtodN+Gq7adLW7UwQP8BW44BRIg99eX5EwoAIS9+MhxW/JxqvsFJ/aHXeT7V5PXtlxflsjavqEQr+R4i9+DGbreGv1/PDIbbAKDG82i1aO4Zvh+2QG6k1BZ87ianDGYEw/I3JtS3mvtmXhT5jXhQoJJGq/BM4zRtwjXhYAs2vGAi/ogzi6ZX8/6GKh2AynvGmTNgtdb1nIRENcWa/+i2WtW1rrNDl9YUv3lZqq+td5qjrWWav64O8R7G9LgGpJ8rqz2NHl/it32TvsK9+bEfT3ne+h6JcX9s4zRoOu0VQACghqJiQWk9CcCsk+LmhFfwJSTm0cDt47LkuISK8qfNDnUVgzKQ0/MOx5/WB7rynooQj7/TVFn9ZKp77/CPnvxdEOHe9+pajd6EgUqkaYlIHQnTfPgAKqdnwnK5NU8l3WoxPdqwRJsxY2OSTzS6ng3hdHup2eQTJ68Uc+oijyUUbbI033d9gAnD8OEN5qa45arvy+SKQzhYCqatvdxVU8w0LR/H+WrMetlHFV0fxFVVwX73sOLP980AFtBfZDq/sYT+y5ndQ+i+bimdnM623dpFIqXohdLaib1Q8UCSk6yOmZmVHZi/ogK/RteYjB96ufnr8tEvTMqdfmT72t1XTM2dWPzNues2MJ2ZVT5lSG6j2UzyYgOs5evJydng35bysuyzVXM/+Y1j12qwVTPK9ALJX9mhj4pXuDy0xPfjaU5B85zWPVHP/0Y+HPbnxLT81v8Hw5zktc+dq4npPbo0/Vui2dnFWWGbWVLPf5+/odT1/6skRc32H9m6UD+z5ype/Z60vf3cu0tfygX3roeBb5+ArV4y9yl1vdSv3vNXrfONbA8oa8BHUGjEgtUlAYN7EjlkQE/vI/D1SeeRrrDJ6hLvBvD1u1Nt7EkbP/2ug4s1wZ+64tYTJ95moTwRLt6EsstcCw6A/7jCPz90TMSl3T/ikr/YYJmzaI6eM+UBR6B8ZFUHXUJgneOXnqz8bF7yKvUqXj9F3jp9vEmiESZHu3397t5zQ9k0JCXGQmPIgJPd+CHqlPgp9BmZJvrBvBYCXLLL0kkKFl8JtzubfFUIrotwmAQAMIQCb2F3fZOmT7gzvl94UlppuN/dE3ivdY05MVR1uoXCsz9yn2M6H692VfxAo6QiCNk0Sjeleak73UX06oyQddOGdzNIVxahTzLEm/7ja3HHVgSZSy2x3CkDWCJTGAIU7jvWN2R+wcd7rXO2JDrtPl8R/e2xzt+1HNiVsOZibtGXfUifR3AVAdlGHw6yAsKnSFDEErnMEE0BBARbqgAuihrlrTUr9Gb1kk4EJgPuSUI+blq3bs+3WDTPebcoZR8jhNweZyjYVmazHzhgu7zqpP7NqqvvcfG3N+llCzedZzqLc7OBqPaywsr/sUw64ZPB47M6xZ7ubjgUaTa1kUSml9i0ejfF2UNhFLVNKNYAkkBI9pSWCw8l8EjNd2rT+EdZQ20Ow1XsCdUN5MAF8+SMBi14PIOrBr4l8r3bdtFR9Q6ENFB8o8k2/EgQiXcNdxfnH639Y3Ldu6yup1t3vDGg8lrsCjh69Zqc5ZFv+SJegO+nwy177d99+Vvb4UL4oqtfoztKaWJE5PxAFTYaOQF5FsrlvSc/w1JIUS+qFJHNqUaIpVffDzs+9F0t6xUx8OheYoql669V3r+kMAhSp+eRSMAMI4eMPKAcBCNXCjY6Hlq4Z/PCyNa0/hCYn66Dn7V1u5H8zeOqi1RPtkR2X1+vMTP4m77D13flL4Nw59R0i9dQpLfGSRfgtcaL/yqWd/vz8mRhTTQx07WqATn26Q1KflIL3Njzj25H3W4vP87y8c9ssR8nJbPS75mweoQqjSJBUGYDwf5jAHz4AD9xbA8E/KrRNxF07j3Sz3/aLnEuGiM9S/5w9AF3htm1H9ndbtCobkgdGc/3HaNjuglH9C6rze5a783tW+vJ7V7jzU5C86b96z9WxU8ewH3a75QP/ngpFx4sCcSIuNe1v0Bofs58+fbb243ffKpv4QHCx7P+Xd8b1WLt+S5/cf23kG5+aBXO/ONSn4wcXX/ntnuvNMh6zdcTAtytcxY2QxwNMxlsRv9pyJ5DxBlFwljbnWYV4IStyqV1vSrZYjB8W/S37JMf8gjhNl5Q0rdvKtc9CQgLeSxy9lpIvNAy8HJ/wlc0YPsSjsCE+WR7iZ3QII2SIaDZFOxe9dalD6ZHw2txlxYHaXWZnF9T06v9LX3mpbF3yz422VR/vQht2Dks8cScZSw2mftRsDC7WusThj+pGLy8zZn2DA0CndicfsQpRqgAhqqgWhDEgVHjDPH4Ds8cOjcKOAV8HVCMWQ7b/YHOlpMpxDTXv5P/63rcRYkhwtoe5UPR4nzLEdslOXrhiKjAWEpV7AAw43zBAK2qOiaLQ0JS78ouKMfd3LU8wkJLuOlIcryfnuhlI7cLX4vdmZ0tqjYR0vWna8/8gE59OETxeJar4zGfuvDVz0Ka2iVw9iYKvkNggJa1NEtnvxNnsx76LqlO7IpgA4HX5tAcn4ER3YIwlBIQlChWXyKBbQkTNEiYKPOPAD2+/21d4mOw4VVt3MvRK371lf6S5oTZdX1cNurrqh9NffVXg/gEaVlQz2kPJMZcCDXJT0xzrnFkT4WT+5YD9Go6f2GKen/xIzG9ffswcEaXv2lC76OjMzGeu8VMBBfijjNLWYUmgeIESCRjaVJ+2Rasnx0mzkz13nNWR88RMR86Yma61o2Z61o6Y6Vj96Myra59awt04HY83vyATstA04Bevx36YMxqwoxwHs3mxV6OZSqsvrTODMjN4FdE4/PvTE52CZolHoyVN/9qyqGTEHasRbj5T06K6zvj74tv/nrN4wNsbFg9atG3xL1bsXDz0/S+XRNw/8lVTRFSyhfmzdw/t9VxzhWvL5t4DkJZxAD8oEXESUoDWWQEhBxpCtHazNfWy53e9r/iOJa/fd90FjciWBQZB+CQqqUc8LjIyj1SaszLJ4rJtMfs8zx18ZmINxzgN+HDNKJsC//QYDNHWN+cV1/9jwQK4dEl9zUz5+661nZ5+ex/tM2xGU8eUGY7YlBn22IQZjTGJM+pF01NE1N4m+PzzjGLEP3isGxLD68/f30N+sRaZwEdOWJubpTVCSAIo1g5R0UeRWSfcmg+UoyLbGtDGz+IU4i3qYfn7mdToBairF+DKJ+/d8X364JH7x42oRUw9tSMn9L3odi5vik/s6Nzwhdcea+4FpUdtkJ1Nu73Bd236CZQIvYxEkSx+u2SRnVKE3yNFeBxSxMkD5edGpmWc7B0+f28i8agBb1AQSVJkWWnzDxJMJDrCQLzuADBOEFcoBbzPETIhBU4FFFwXmvZ+e2cAuWU+eHB4WNrdCzs+MSmqQ01lWXJi8iAcuNL/j6tMCeyeN/xEN13yS5c0m/8UdvbF4ZoTz96rOfZUmubI+EGaw48N0Byc8WgilJ7ZdjPtirHRhOi0ROP1trozPjD+s3GbpShop0EJBdbuPvEeOQiSzQZin9T1kNL/1pOQkKCPm/PW69FPPv2gBeQiS1jYlF2jh6vPdLtLmYcX+U++msu1rv1fvFS+d++PXl3s3o+eye8v7erq0Hm4HB5FDdaa3KAzk/0MQGo3tKA5JAEUffjtErSBY8+3XwqydEqTlq6LWbh0cUKZe2VCKRLyxIvulT2QEsucKzn1QKxHmWNlMmJcTkC927ajK7SD056lklRJZf8zu/p2Vl9k4kb+aYVL0+FlX2MdyOf3r3JcOrsFGCM9sU5ymXdlMufYTmIxtnXBsTKx1LkyoYUS0dbjondlM3c396HCu1K+99HlHkv4qCi/B5z11uzAKHALI+GjAacypiEAhnAakFWBtXWq/eDN4zqNKSPZWmUTe/e9XVFYFvpliYRkiYxm4WKbJQDJIkgSY1m4kcnyoY8MDHHI0hpMmWZFooIkpx9O7vBv3lbYgMff9cXfn6UQM5glWy64G16Hor2O+GLHaTdTsmQmZzGMpSABZVmAbWG3sgDbYCjjQpOlKArqaGOAbUMWVeQswWx+EC5fBMe3m2f/ouuwCxA48G0KFzeGcQJIG47jadExMsEVT/S7jC2Iyor6RVXsuSMp4kqymVT0MJLSJAMpTtCTCwm4aUlEOdFISpEuJhlJBSeUy5FKVJueFPWwkMKeEaU8mKbnfb+EAU+Owr0FCZMafihbNmtc494VjdxWmRKWWplkImUYowSpFNvicnmyiZT3QELsIsa9iHHLVDKSEtw8FXc3IDeS4kQTufjo3eT8i08vXHIHCe76LD3vGYgbrkSK2wHeTnsKJoA4L9tBcnlE1lgGCb+Ia+/4c3XD+C/i9XfN/iuhuiSdq+67sg8fu/vnxvyp+t0y/hTpj7otVdGGa02OCweu5x9MgO907hbw4TQkEWBIfuy92AfnPnq9Cv8JZp66LVowRr/DBNMISsjqmuVPtL49/icBb6JOAv7s7jUk/YMQOl0r2cGnj8i8XrVgArzndpwTRTJbANlOYm7LdEYN+NCQtTPHFKDJ23JMEzchbcgxjP86xzDx6xzTpM05FsQtWTua+eQdOeasb7AOEuLc3zx+Qw7zyZ8zWRqLtFyB8BcACIsdvyrHNHFzjgljmTCWAWMbUDeM34SxkSZtzDFP2orxduSYeNzJO3Oa28E2Jm/FurwvG9X6FoxhxhgW7I958jc5pqd25tQp8Ws9hi7PCPpwYmSOdw2eqjq4zhFMALc1rn9qH6Wkv7GxAHDaxIPCMhVZylQkT6YsyZm4TGQy0GQyQjMZo5kKFTMlEDJlgEwJMc4VJmfiQJEU9EeboM/EbdjDRPJ8qXU0zLYvG2rt8vj7F5rEjpkyRTvVYn0R40EmAZIJBAloJmA7CnJc8DAW9kH2ZkqMqSQzMVMh2kwFxEzgfaAUZaLaFNmfyfz+TEWRxyieBjeU7vybYrTMu7I528XH2J5oe6Bx7eMX67b9mbjyf6MXjr/3BD2x6E3vsc/qKb4OC47qk8LJpX/SnFo6R3Ny2Z/p0Y8XiFUHtvIghBA3Lfpshfb40n/SgsXz4PjiueTkonnCicXzyMlPn3KsGT22IXecLSEhQd94dtdmUrD0fXpy8QdC4eL3xFOfviEUfPouKVz8pnBq6Xti4bKFQsHSD+jxJX+jxxfNV44v+gQaSyuJwgCunpbEgsXLxIIlS4TC5R+SE5++QYvWvQrc1njhKC345FU49tF01+qHaVPuk8aGHz54hX9qaz/OgM77HpDb8uJir+P0tg3O05vnGKjnbwohAOZYGxk4/SS5/TcnyKBpx0nKiKN+qosDyQO0Ym9208T0N04AAAF+SURBVFFleuOpr190FG6a7zqz+Q3X6a3zHac3zW86vWllIHh5ebnHeTpvtrPg6xdchXnPOws3/d5RkDfXeXrTH5yFm+dg3d83FX4921G48XlH0devOE5vmec5s+03EYL9fUFyOKBjH5n0m/gVuX3K1/T2aVvZoBnfQ+rEAhB0IIcn73Kc2pLtOrOV/88AZivQ6o35jRMQUocpsp5QEWSiGS6BuF0mZLvMhO3M3CkHOzRYUFw7TbHd1gPk4l0QUvF/Ubyyee7blMmvgOLVSUzcKjOKfWDbGWPbFQIbGBCgVAO3etxUAvSiuFd79bCivXoIxOrDIFQhv3oExKvHQKw7tV8RxWerc35TfquN36p/4/oJ70PVkRXa2qOSpuawTag5ZBWqD/iEqoNuTXV+k/bqgVu+ADeVAOsp40GN+1K8xlXRRetuJi5rXJVdqOvSKPvqccHPVrc6qFv1d9X++znRW9NNY6vorW+6kqrzXU3Q2Wp66OwVPTWuS3+/1Xj/DwAA//+Tu3vuAAAABklEQVQDAC/MxT6haoWCAAAAAElFTkSuQmCC';
function Sidebar({
  active = 'catalog',
  onNavigate,
  theme = 'dark',
  onToggleTheme
}) {
  const items = [{
    key: 'catalog',
    label: 'Catálogo',
    icon: 'library'
  }, {
    key: 'add',
    label: 'Adicionar',
    icon: 'plus-circle'
  }, {
    key: 'recommend',
    label: 'Recomendar',
    icon: 'wand-2'
  }];
  return React.createElement('nav', {
    style: {
      width: 'var(--sidebar-width)',
      flexShrink: 0,
      background: 'var(--color-surface)',
      borderRight: '1px solid var(--color-border)',
      padding: 'var(--space-4)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)',
      height: '100%',
      boxSizing: 'border-box'
    }
  }, React.createElement('div', {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, React.createElement('div', {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, React.createElement('img', {
    src: LOGO_SYMBOL_SRC,
    alt: '',
    style: {
      width: 22,
      height: 22,
      objectFit: 'contain'
    }
  }), React.createElement('span', {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 700,
      fontSize: 16,
      color: 'var(--color-text)'
    }
  }, 'SkillVault')), React.createElement(__ds_scope.IconButton, {
    name: theme === 'dark' ? 'sun' : 'moon',
    label: 'Alternar tema',
    onClick: onToggleTheme
  })), React.createElement('div', {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, items.map(it => React.createElement('button', {
    key: it.key,
    type: 'button',
    onClick: () => onNavigate && onNavigate(it.key),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '9px 10px',
      border: 'none',
      borderRadius: 'var(--radius-md)',
      cursor: 'pointer',
      textAlign: 'left',
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      fontWeight: 500,
      background: active === it.key ? 'var(--color-surface-hover)' : 'transparent',
      color: active === it.key ? 'var(--color-text)' : 'var(--color-text-secondary)'
    }
  }, React.createElement(__ds_scope.Icon, {
    name: it.icon,
    size: 17
  }), it.label))));
}
Object.assign(__ds_scope, { Sidebar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Sidebar/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/skillvault-web/AddScreen.jsx
try { (() => {
window.AddScreen = function AddScreen({
  categories,
  onCreated
}) {
  const {
    Select,
    Input,
    Textarea,
    Tabs,
    Button,
    StatusMessage,
    Icon
  } = window.SkillVaultDesignSystem_31593f;
  const [type, setType] = React.useState('repo');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      maxWidth: 520
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-display)',
      fontWeight: 'var(--fw-display)',
      color: 'var(--color-text)'
    }
  }, "Adicionar item"), /*#__PURE__*/React.createElement(Select, {
    label: "Tipo",
    value: type,
    onChange: e => setType(e.target.value),
    style: {
      width: 220
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "repo"
  }, "Reposit\xF3rio"), /*#__PURE__*/React.createElement("option", {
    value: "skill"
  }, "Skill"), /*#__PURE__*/React.createElement("option", {
    value: "mcp"
  }, "MCP")), type === 'repo' && /*#__PURE__*/React.createElement(RepoForm, {
    onCreated: onCreated
  }), type === 'skill' && /*#__PURE__*/React.createElement(SkillForm, {
    onCreated: onCreated
  }), type === 'mcp' && /*#__PURE__*/React.createElement(McpForm, {
    onCreated: onCreated
  }));
};
function RepoForm({
  onCreated
}) {
  const {
    Input,
    Button,
    StatusMessage
  } = window.SkillVaultDesignSystem_31593f;
  const [name, setName] = React.useState('');
  const [url, setUrl] = React.useState('');
  const [status, setStatus] = React.useState('idle');
  function submit(e) {
    e.preventDefault();
    setStatus('submitting');
    setTimeout(() => {
      setStatus('idle');
      onCreated('repo', name || 'novo-repo');
    }, 500);
  }
  return /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-lg)',
      padding: 18
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Nome",
    value: name,
    onChange: e => setName(e.target.value),
    placeholder: "fastify-starter",
    required: true
  }), /*#__PURE__*/React.createElement(Input, {
    label: "URL do reposit\xF3rio",
    value: url,
    onChange: e => setUrl(e.target.value),
    placeholder: "https://github.com/org/repo.git",
    required: true
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    disabled: status === 'submitting'
  }, status === 'submitting' ? 'Clonando...' : 'Adicionar repositório')));
}
function SkillForm({
  onCreated
}) {
  const {
    Input,
    Tabs,
    Button
  } = window.SkillVaultDesignSystem_31593f;
  const [name, setName] = React.useState('');
  const [tab, setTab] = React.useState('local_path');
  const [status, setStatus] = React.useState('idle');
  function submit(e) {
    e.preventDefault();
    setStatus('submitting');
    setTimeout(() => {
      setStatus('idle');
      onCreated('skill', name || 'nova-skill');
    }, 500);
  }
  return /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-lg)',
      padding: 18
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Nome",
    value: name,
    onChange: e => setName(e.target.value),
    placeholder: "pdf-parser",
    required: true
  }), /*#__PURE__*/React.createElement(Tabs, {
    tabs: [{
      value: 'local_path',
      label: 'Caminho local'
    }, {
      value: 'upload',
      label: 'Upload'
    }, {
      value: 'url',
      label: 'URL'
    }],
    value: tab,
    onChange: setTab
  }), tab === 'local_path' && /*#__PURE__*/React.createElement(Input, {
    label: "Caminho local da pasta",
    placeholder: "C:\\\\Users\\\\Diogo\\\\skills\\\\pdf-parser",
    required: true
  }), tab === 'upload' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--color-text-secondary)'
    }
  }, "Arquivo (SKILL.md ou .zip)"), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px dashed var(--color-border-strong)',
      borderRadius: 'var(--radius-md)',
      padding: '18px',
      textAlign: 'center',
      color: 'var(--color-text-tertiary)',
      fontFamily: 'var(--font-sans)',
      fontSize: 13
    }
  }, "Arraste um arquivo ou clique para selecionar")), tab === 'url' && /*#__PURE__*/React.createElement(Input, {
    label: "URL do reposit\xF3rio da skill",
    placeholder: "https://github.com/org/skill.git",
    required: true
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    disabled: status === 'submitting'
  }, status === 'submitting' ? 'Enviando...' : 'Adicionar skill')));
}
function McpForm({
  onCreated
}) {
  const {
    Input,
    Textarea,
    Button
  } = window.SkillVaultDesignSystem_31593f;
  const [name, setName] = React.useState('');
  const [config, setConfig] = React.useState('{\n  "mcpServers": {\n    "example": { "command": "npx", "args": ["-y", "@example/mcp"] }\n  }\n}');
  const [status, setStatus] = React.useState('idle');
  function submit(e) {
    e.preventDefault();
    setStatus('submitting');
    setTimeout(() => {
      setStatus('idle');
      onCreated('mcp', name || 'novo-mcp');
    }, 500);
  }
  return /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-lg)',
      padding: 18
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Nome",
    value: name,
    onChange: e => setName(e.target.value),
    placeholder: "filesystem-mcp",
    required: true
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Descri\xE7\xE3o (opcional)",
    placeholder: "Acesso ao sistema de arquivos"
  }), /*#__PURE__*/React.createElement(Textarea, {
    label: "Config JSON (ex: bloco mcpServers)",
    mono: true,
    value: config,
    onChange: e => setConfig(e.target.value),
    required: true
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    disabled: status === 'submitting'
  }, status === 'submitting' ? 'Salvando...' : 'Adicionar MCP')));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/skillvault-web/AddScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/skillvault-web/App.jsx
try { (() => {
window.App = function App() {
  const {
    Sidebar
  } = window.SkillVaultDesignSystem_31593f;
  const [theme, setTheme] = React.useState('dark');
  const [route, setRoute] = React.useState('catalog');
  const [openId, setOpenId] = React.useState(null);
  const [items, setItems] = React.useState(window.MOCK_ITEMS);
  const [categories, setCategories] = React.useState(window.MOCK_CATEGORIES);
  const [toast, setToast] = React.useState('');
  React.useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);
  function handleOpenItem(id) {
    setOpenId(id);
    setRoute('detail');
  }
  function handleBack() {
    setOpenId(null);
    setRoute('catalog');
  }
  function handleSaveItem(patch) {
    setItems(items.map(it => it.id === openId ? {
      ...it,
      ...patch
    } : it));
  }
  function handleRenameCategory(id, name) {
    setCategories(categories.map(c => c.id === id ? {
      ...c,
      name
    } : c));
  }
  function handleMergeCategory(srcId, tgtId) {
    setItems(items.map(it => it.categoryId === srcId ? {
      ...it,
      categoryId: tgtId
    } : it));
    setCategories(categories.filter(c => c.id !== srcId));
  }
  function handleCreated(type, name) {
    const nextId = Math.max(...items.map(i => i.id)) + 1;
    const newItem = {
      id: nextId,
      type,
      name,
      categoryId: null,
      summary: 'Enriquecendo via LLM...',
      utility: '',
      tags: [],
      localPath: `~/skillvault/${type}s/${name}`,
      enrichmentSource: 'manual',
      content: `# ${name}\n\nConteúdo recém-adicionado.`
    };
    setItems([...items, newItem]);
    setToast(`"${name}" adicionado ao catálogo.`);
    setTimeout(() => setToast(''), 2400);
    handleOpenItem(nextId);
  }
  const openItem = items.find(i => i.id === openId);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100vh',
      background: 'var(--color-bg)'
    }
  }, /*#__PURE__*/React.createElement(Sidebar, {
    active: route === 'detail' ? 'catalog' : route,
    onNavigate: k => {
      setRoute(k);
      setOpenId(null);
    },
    theme: theme,
    onToggleTheme: () => setTheme(t => t === 'dark' ? 'light' : 'dark')
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      padding: 32,
      position: 'relative'
    }
  }, toast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      top: 20,
      right: 20,
      background: 'var(--color-surface-raised)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-md)',
      padding: '10px 16px',
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      color: 'var(--color-text)',
      boxShadow: 'var(--shadow-md)'
    }
  }, toast), route === 'catalog' && /*#__PURE__*/React.createElement(window.CatalogScreen, {
    items: items,
    categories: categories,
    onOpenItem: handleOpenItem,
    onRenameCategory: handleRenameCategory,
    onMergeCategory: handleMergeCategory
  }), route === 'detail' && openItem && /*#__PURE__*/React.createElement(window.ItemDetailScreen, {
    item: openItem,
    categories: categories,
    onBack: handleBack,
    onSave: handleSaveItem
  }), route === 'add' && /*#__PURE__*/React.createElement(window.AddScreen, {
    categories: categories,
    onCreated: handleCreated
  }), route === 'recommend' && /*#__PURE__*/React.createElement(window.RecommendScreen, {
    items: items
  })));
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/skillvault-web/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/skillvault-web/CatalogScreen.jsx
try { (() => {
window.CatalogScreen = function CatalogScreen({
  items,
  categories,
  onOpenItem,
  onRenameCategory,
  onMergeCategory
}) {
  const {
    Input,
    Select,
    ItemCard,
    Icon,
    Button,
    StatusMessage
  } = window.SkillVaultDesignSystem_31593f;
  const [q, setQ] = React.useState('');
  const [type, setType] = React.useState('');
  const [categoryId, setCategoryId] = React.useState('');
  const [showCategories, setShowCategories] = React.useState(false);
  const filtered = items.filter(it => {
    if (q && !(it.name.toLowerCase().includes(q.toLowerCase()) || it.summary.toLowerCase().includes(q.toLowerCase()))) return false;
    if (type && it.type !== type) return false;
    if (categoryId && String(it.categoryId) !== categoryId) return false;
    return true;
  });
  const groups = {};
  filtered.forEach(it => {
    const cat = categories.find(c => c.id === it.categoryId);
    const name = cat ? cat.name : 'Sem categoria';
    (groups[name] = groups[name] || []).push(it);
  });
  const groupNames = Object.keys(groups).sort();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-display)',
      fontWeight: 'var(--fw-display)',
      letterSpacing: 'var(--ls-display)',
      color: 'var(--color-text)'
    }
  }, "Cat\xE1logo"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '4px 0 0',
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      color: 'var(--color-text-tertiary)'
    }
  }, filtered.length, " de ", items.length, " itens")), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "folder-cog",
      size: 15
    }),
    onClick: () => setShowCategories(s => !s)
  }, "Gerenciar categorias")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-end',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "Buscar por nome ou resumo...",
    "aria-label": "Buscar",
    value: q,
    onChange: e => setQ(e.target.value),
    style: {
      width: 280
    }
  }), /*#__PURE__*/React.createElement(Select, {
    "aria-label": "Tipo",
    value: type,
    onChange: e => setType(e.target.value),
    style: {
      width: 160
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Todos os tipos"), /*#__PURE__*/React.createElement("option", {
    value: "skill"
  }, "Skill"), /*#__PURE__*/React.createElement("option", {
    value: "repo"
  }, "Repo"), /*#__PURE__*/React.createElement("option", {
    value: "mcp"
  }, "MCP")), /*#__PURE__*/React.createElement(Select, {
    "aria-label": "Categoria",
    value: categoryId,
    onChange: e => setCategoryId(e.target.value),
    style: {
      width: 190
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Todas as categorias"), categories.map(c => /*#__PURE__*/React.createElement("option", {
    key: c.id,
    value: c.id
  }, c.name)))), showCategories && /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-lg)',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 10px',
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      color: 'var(--color-text)'
    }
  }, "Categorias"), /*#__PURE__*/React.createElement(CategoryManagerInline, {
    categories: categories,
    onRename: onRenameCategory,
    onMerge: onMergeCategory
  })), groupNames.length === 0 && /*#__PURE__*/React.createElement(StatusMessage, {
    kind: "info"
  }, "Nenhum item corresponde aos filtros."), groupNames.map(name => /*#__PURE__*/React.createElement("section", {
    key: name,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-title)',
      fontWeight: 'var(--fw-title)',
      color: 'var(--color-text)'
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
      gap: 14
    }
  }, groups[name].map(it => /*#__PURE__*/React.createElement(ItemCard, {
    key: it.id,
    item: it,
    onOpen: () => onOpenItem(it.id)
  }))))));
};
function CategoryManagerInline({
  categories,
  onRename,
  onMerge
}) {
  const {
    Input,
    Select,
    Button
  } = window.SkillVaultDesignSystem_31593f;
  const [renamingId, setRenamingId] = React.useState(null);
  const [renameValue, setRenameValue] = React.useState('');
  const [src, setSrc] = React.useState('');
  const [tgt, setTgt] = React.useState('');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, categories.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, renamingId === c.id ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Input, {
    value: renameValue,
    onChange: e => setRenameValue(e.target.value),
    style: {
      width: 200
    }
  }), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    onClick: () => {
      onRename(c.id, renameValue);
      setRenamingId(null);
    }
  }, "Salvar")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--color-text)',
      width: 200
    }
  }, c.name), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost",
    onClick: () => {
      setRenamingId(c.id);
      setRenameValue(c.name);
    }
  }, "Renomear"))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      alignItems: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Mesclar categoria",
    value: src,
    onChange: e => setSrc(e.target.value),
    style: {
      width: 170
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Selecione a origem"), categories.map(c => /*#__PURE__*/React.createElement("option", {
    key: c.id,
    value: c.id
  }, c.name))), /*#__PURE__*/React.createElement(Select, {
    label: "Em",
    value: tgt,
    onChange: e => setTgt(e.target.value),
    style: {
      width: 170
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Selecione o destino"), categories.map(c => /*#__PURE__*/React.createElement("option", {
    key: c.id,
    value: c.id
  }, c.name))), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    disabled: !src || !tgt,
    onClick: () => {
      onMerge(Number(src), Number(tgt));
      setSrc('');
      setTgt('');
    }
  }, "Mesclar")));
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/skillvault-web/CatalogScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/skillvault-web/ItemDetailScreen.jsx
try { (() => {
window.ItemDetailScreen = function ItemDetailScreen({
  item,
  categories,
  onBack,
  onSave
}) {
  const {
    TypeBadge,
    Button,
    Select,
    Input,
    Tag,
    StatusMessage,
    Icon
  } = window.SkillVaultDesignSystem_31593f;
  const [copied, setCopied] = React.useState(false);
  const [categoryId, setCategoryId] = React.useState(item.categoryId != null ? String(item.categoryId) : '');
  const [tagsInput, setTagsInput] = React.useState(item.tags.join(', '));
  const [saveStatus, setSaveStatus] = React.useState('idle');
  function handleCopy() {
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }
  function handleSave() {
    setSaveStatus('saving');
    setTimeout(() => {
      onSave({
        categoryId: categoryId ? Number(categoryId) : null,
        tags: tagsInput.split(',').map(t => t.trim()).filter(Boolean)
      });
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 1600);
    }, 400);
  }
  const isMcp = item.type === 'mcp';
  const enrichmentLabel = {
    ollama: 'Ollama (local)',
    gemini: 'Gemini 2.0 Flash',
    manual: 'Manual'
  }[item.enrichmentSource];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onBack,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      background: 'none',
      border: 'none',
      color: 'var(--color-text-tertiary)',
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      cursor: 'pointer',
      padding: 0,
      alignSelf: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-left",
    size: 14
  }), " Voltar ao cat\xE1logo"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-display)',
      fontWeight: 'var(--fw-display)',
      color: 'var(--color-text)'
    }
  }, item.name), /*#__PURE__*/React.createElement(TypeBadge, {
    type: item.type
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 15,
      color: 'var(--color-text-secondary)'
    }
  }, item.summary), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      color: 'var(--color-text-tertiary)'
    }
  }, item.utility), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("code", {
    style: {
      background: 'var(--color-bg-inset)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-md)',
      padding: '6px 10px',
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      color: 'var(--color-text-secondary)'
    }
  }, item.localPath), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: copied ? 'check' : 'copy',
      size: 13
    }),
    onClick: handleCopy
  }, copied ? 'Copiado!' : 'Copiar caminho'), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 12,
      color: 'var(--color-text-tertiary)'
    }
  }, "Enriquecido via ", enrichmentLabel)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'flex-end',
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-lg)',
      padding: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Categoria",
    value: categoryId,
    onChange: e => setCategoryId(e.target.value),
    style: {
      width: 200
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Sem categoria"), categories.map(c => /*#__PURE__*/React.createElement("option", {
    key: c.id,
    value: c.id
  }, c.name))), /*#__PURE__*/React.createElement(Input, {
    label: "Tags (separadas por v\xEDrgula)",
    value: tagsInput,
    onChange: e => setTagsInput(e.target.value),
    style: {
      width: 260
    }
  }), /*#__PURE__*/React.createElement(Button, {
    onClick: handleSave,
    disabled: saveStatus === 'saving'
  }, "Salvar"), saveStatus === 'saved' && /*#__PURE__*/React.createElement(StatusMessage, {
    kind: "success"
  }, "Salvo!")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, tagsInput.split(',').map(t => t.trim()).filter(Boolean).map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--color-surface)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-lg)',
      padding: 20
    }
  }, isMcp ? /*#__PURE__*/React.createElement("pre", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      color: 'var(--color-text-secondary)',
      whiteSpace: 'pre-wrap'
    }
  }, item.content) : /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      lineHeight: 1.7,
      color: 'var(--color-text-secondary)'
    }
  }, item.content.split('\n').map((line, i) => {
    if (line.startsWith('## ')) return /*#__PURE__*/React.createElement("h3", {
      key: i,
      style: {
        fontSize: 16,
        color: 'var(--color-text)',
        margin: '14px 0 6px'
      }
    }, line.slice(3));
    if (line.startsWith('# ')) return /*#__PURE__*/React.createElement("h2", {
      key: i,
      style: {
        fontSize: 18,
        color: 'var(--color-text)',
        margin: '0 0 10px'
      }
    }, line.slice(2));
    if (!line.trim()) return null;
    return /*#__PURE__*/React.createElement("p", {
      key: i,
      style: {
        margin: '0 0 8px'
      }
    }, line);
  }))));
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/skillvault-web/ItemDetailScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/skillvault-web/RecommendScreen.jsx
try { (() => {
window.RecommendScreen = function RecommendScreen({
  items
}) {
  const {
    Textarea,
    Button,
    ItemCard,
    StatusMessage,
    Icon
  } = window.SkillVaultDesignSystem_31593f;
  const [idea, setIdea] = React.useState('');
  const [result, setResult] = React.useState(null);
  function submit(e) {
    e.preventDefault();
    if (!idea.trim()) return;
    const matched = items.filter(it => idea.toLowerCase().includes(it.tags[0]) || it.summary.toLowerCase().split(' ').some(w => idea.toLowerCase().includes(w) && w.length > 4));
    setResult({
      skill: matched.filter(i => i.type === 'skill'),
      repo: matched.filter(i => i.type === 'repo'),
      mcp: matched.filter(i => i.type === 'mcp')
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      maxWidth: 900
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-display)',
      fontWeight: 'var(--fw-display)',
      color: 'var(--color-text)'
    }
  }, "Recomendar"), /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Textarea, {
    label: "Descreva a ideia do projeto",
    placeholder: "Ex: preciso gerar relat\xF3rios em PDF a partir de dados de um banco Postgres",
    value: idea,
    onChange: e => setIdea(e.target.value)
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "wand-2",
      size: 14
    })
  }, "Recomendar do cat\xE1logo"))), result && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 16
    }
  }, ['skill', 'repo', 'mcp'].map(t => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      textTransform: 'uppercase',
      letterSpacing: '.04em',
      color: 'var(--color-text-tertiary)'
    }
  }, t === 'skill' ? 'Skills' : t === 'repo' ? 'Repos' : 'MCPs'), result[t].length === 0 && /*#__PURE__*/React.createElement(StatusMessage, {
    kind: "info"
  }, "Nenhum ", t, " do cat\xE1logo cobre essa necessidade."), result[t].map(it => /*#__PURE__*/React.createElement(ItemCard, {
    key: it.id,
    item: it,
    onOpen: () => {}
  }))))));
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/skillvault-web/RecommendScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/skillvault-web/mock-data.js
try { (() => {
window.MOCK_CATEGORIES = [{
  id: 1,
  name: 'Automação'
}, {
  id: 2,
  name: 'Documentação'
}, {
  id: 3,
  name: 'Infraestrutura'
}];
window.MOCK_ITEMS = [{
  id: 1,
  type: 'skill',
  name: 'pdf-parser',
  categoryId: 1,
  summary: 'Extrai texto e tabelas de PDFs complexos.',
  utility: 'Útil para pipelines de ingestão de documentos e relatórios financeiros.',
  tags: ['pdf', 'extraction'],
  localPath: '~/skillvault/skills/pdf-parser',
  enrichmentSource: 'ollama',
  content: '# pdf-parser\n\nExtrai texto, tabelas e metadados de arquivos PDF, incluindo documentos escaneados via OCR opcional.\n\n## Uso\n\nInvoque quando precisar transformar um PDF em texto estruturado ou markdown.'
}, {
  id: 2,
  type: 'skill',
  name: 'video-thumbnails',
  categoryId: 1,
  summary: 'Gera thumbnails de vídeo a partir de timestamps.',
  utility: 'Acelera a criação de capas para conteúdo em vídeo.',
  tags: ['video', 'ffmpeg'],
  localPath: '~/skillvault/skills/video-thumbnails',
  enrichmentSource: 'gemini',
  content: '# video-thumbnails\n\nGera imagens estáticas a partir de timestamps de um vídeo usando ffmpeg.'
}, {
  id: 3,
  type: 'repo',
  name: 'shadcn-admin',
  categoryId: 2,
  summary: 'Template de admin dashboard em React + Tailwind.',
  utility: 'Referência de layout para painéis internos.',
  tags: ['react', 'dashboard'],
  localPath: '~/skillvault/repos/shadcn-admin',
  enrichmentSource: 'ollama',
  content: '# shadcn-admin\n\nDashboard administrativo com sidebar, tabelas e gráficos, construído sobre shadcn/ui.'
}, {
  id: 4,
  type: 'repo',
  name: 'fastify-starter',
  categoryId: 3,
  summary: 'Boilerplate de API Fastify com autenticação JWT.',
  utility: 'Ponto de partida para novos serviços backend.',
  tags: ['fastify', 'api'],
  localPath: '~/skillvault/repos/fastify-starter',
  enrichmentSource: 'manual',
  content: '# fastify-starter\n\nEstrutura mínima de API REST com Fastify, JWT e testes com Vitest.'
}, {
  id: 5,
  type: 'mcp',
  name: 'filesystem-mcp',
  categoryId: 3,
  summary: 'Acesso controlado ao sistema de arquivos local.',
  utility: 'Permite ao Claude Code ler/escrever arquivos do projeto.',
  tags: ['fs', 'core'],
  localPath: '~/skillvault/mcps/filesystem-mcp.json',
  enrichmentSource: 'manual',
  content: '{\n  "mcpServers": {\n    "filesystem": {\n      "command": "npx",\n      "args": ["-y", "@modelcontextprotocol/server-filesystem", "."]\n    }\n  }\n}'
}, {
  id: 6,
  type: 'mcp',
  name: 'postgres-mcp',
  categoryId: 3,
  summary: 'Consulta bancos Postgres locais em modo leitura.',
  utility: 'Dá contexto de schema real ao Claude Code durante o desenvolvimento.',
  tags: ['sql', 'db'],
  localPath: '~/skillvault/mcps/postgres-mcp.json',
  enrichmentSource: 'ollama',
  content: '{\n  "mcpServers": {\n    "postgres": {\n      "command": "npx",\n      "args": ["-y", "@modelcontextprotocol/server-postgres", "postgres://localhost/db"]\n    }\n  }\n}'
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/skillvault-web/mock-data.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.ItemCard = __ds_scope.ItemCard;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.TypeBadge = __ds_scope.TypeBadge;

__ds_ns.StatusMessage = __ds_scope.StatusMessage;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Sidebar = __ds_scope.Sidebar;

})();
