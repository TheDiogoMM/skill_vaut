Free-form catalog tag (mono type, matches how tags read like machine keywords: `pdf`, `automation`, `git`).

```jsx
{item.tags.map(t => <Tag key={t}>{t}</Tag>)}
<Tag onRemove={() => removeTag(t)}>{t}</Tag>
```
