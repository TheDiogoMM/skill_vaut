export function Tag({ children, onRemove, style }) {
  return React.createElement('span', {
    style: {
      display: 'inline-flex', alignItems: 'center', gap: 4, padding: '3px 9px',
      background: 'var(--color-surface-hover)', border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-full)', color: 'var(--color-text-secondary)',
      fontFamily: 'var(--font-mono)', fontSize: 12, ...style
    }
  }, children, onRemove && React.createElement('button', {
    type: 'button', onClick: onRemove, 'aria-label': 'Remover tag',
    style: { border: 'none', background: 'none', color: 'inherit', cursor: 'pointer', padding: 0, display: 'flex', opacity: .7 }
  }, '\u00d7'));
}
