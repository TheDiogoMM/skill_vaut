export interface CatalogItem {
  id: number;
  type: 'skill' | 'repo' | 'mcp';
  name: string;
  summary?: string | null;
  utility?: string | null;
  tags: string[];
  localPath?: string;
}
/**
 * @startingPoint section="Components" subtitle="Catalog card — name, summary, tags, path" viewport="700x220"
 */
export interface ItemCardProps {
  item: CatalogItem;
  onOpen?: () => void;
}
export function ItemCard(props: ItemCardProps): JSX.Element;
