The catalog's core unit — one per skill/repo/MCP, grouped by category on the Catalog screen. Composes `TypeBadge` and `Tag`.

```jsx
<ItemCard item={item} onOpen={() => navigate(`/items/${item.id}`)} />
```

Hover lightens the border only (no background/shadow pop — keeps dense grids calm).
