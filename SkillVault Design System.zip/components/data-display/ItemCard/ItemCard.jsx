import { TypeBadge } from '../TypeBadge/TypeBadge.jsx';
import { Tag } from '../Tag/Tag.jsx';

export function ItemCard({ item, onOpen }) {
  return React.createElement('div', {
    role: 'button', tabIndex: 0, onClick: onOpen,
    style: {
      display: 'flex', flexDirection: 'column', gap: 8, padding: 'var(--space-4)',
      background: 'var(--color-surface)', border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-lg)', cursor: 'pointer', fontFamily: 'var(--font-sans)',
      transition: 'border-color var(--duration-fast) var(--ease-out), transform var(--duration-fast)'
    },
    onMouseEnter: e => e.currentTarget.style.borderColor = 'var(--color-border-strong)',
    onMouseLeave: e => e.currentTarget.style.borderColor = 'var(--color-border)'
  },
    React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 } },
      React.createElement('span', { style: { fontSize: 15, fontWeight: 600, color: 'var(--color-text)' } }, item.name),
      React.createElement(TypeBadge, { type: item.type, size: 'sm' })
    ),
    item.summary && React.createElement('p', { style: { margin: 0, fontSize: 13, color: 'var(--color-text-secondary)', lineHeight: 1.5 } }, item.summary),
    item.utility && React.createElement('p', { style: { margin: 0, fontSize: 12, color: 'var(--color-text-tertiary)' } }, item.utility),
    item.tags && item.tags.length > 0 && React.createElement('div', { style: { display: 'flex', gap: 6, flexWrap: 'wrap' } },
      item.tags.map(t => React.createElement(Tag, { key: t }, t))
    ),
    item.localPath && React.createElement('code', { style: { fontSize: 11, color: 'var(--color-text-tertiary)', fontFamily: 'var(--font-mono)' } }, item.localPath)
  );
}
