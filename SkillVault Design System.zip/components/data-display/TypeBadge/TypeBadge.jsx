import { Icon } from '../../core/Icon/Icon.jsx';

const CONFIG = {
  skill: { label: 'Skill', color: 'var(--color-type-skill)', bg: 'var(--color-type-skill-bg)', icon: 'sparkles' },
  repo: { label: 'Repo', color: 'var(--color-type-repo)', bg: 'var(--color-type-repo-bg)', icon: 'git-branch' },
  mcp: { label: 'MCP', color: 'var(--color-type-mcp)', bg: 'var(--color-type-mcp-bg)', icon: 'plug' }
};

export function TypeBadge({ type, size = 'md' }) {
  const c = CONFIG[type] || CONFIG.skill;
  const pad = size === 'sm' ? '3px 8px' : '4px 10px';
  const font = size === 'sm' ? 11 : 12;
  return React.createElement('span', {
    style: {
      display: 'inline-flex', alignItems: 'center', gap: 5, padding: pad,
      borderRadius: 'var(--radius-full)', background: c.bg, color: c.color,
      border: `1px solid color-mix(in oklch, ${c.color} 45%, transparent)`,
      fontFamily: 'var(--font-sans)', fontSize: font, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.04em'
    }
  }, React.createElement(Icon, { name: c.icon, size: font + 2 }), c.label);
}
