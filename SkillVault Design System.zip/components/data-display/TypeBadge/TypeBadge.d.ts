/**
 * @startingPoint section="Components" subtitle="Skill/Repo/MCP identity pill" viewport="700x110"
 */
export interface TypeBadgeProps {
  type: 'skill' | 'repo' | 'mcp';
  size?: 'sm' | 'md';
}
export function TypeBadge(props: TypeBadgeProps): JSX.Element;
