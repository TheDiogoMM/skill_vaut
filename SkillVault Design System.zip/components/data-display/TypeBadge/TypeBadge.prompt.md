Item-type identity pill shown on every catalog card and detail page. Each type has a fixed color + icon: Skill (violet/sparkles), Repo (green/git-branch), MCP (amber/plug) — never reassign these.

```jsx
<TypeBadge type="repo" />
<TypeBadge type="mcp" size="sm" />
```
