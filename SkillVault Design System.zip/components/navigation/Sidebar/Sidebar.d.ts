/**
 * @startingPoint section="Components" subtitle="Fixed left nav — collapses below 720px in product" viewport="700x360"
 */
export interface SidebarProps {
  active?: 'catalog' | 'add' | 'recommend';
  onNavigate?: (key: string) => void;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
}
export function Sidebar(props: SidebarProps): JSX.Element;
