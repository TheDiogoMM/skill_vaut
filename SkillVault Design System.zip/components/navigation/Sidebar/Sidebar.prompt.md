Fixed left navigation (desktop-first — the product's explicit layout decision). Collapses to a top bar under 720px in the real app.

```jsx
<Sidebar active="catalog" onNavigate={setRoute} theme={theme} onToggleTheme={toggleTheme} />
```
