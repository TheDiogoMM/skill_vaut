Native `<select>` styled to match Input — used for item type, category assignment, category merge source/target.

```jsx
<Select label="Categoria" value={categoryId} onChange={onChange}>
  <option value="">Sem categoria</option>
  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
</Select>
```
