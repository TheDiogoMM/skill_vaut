export function Select({ label, id, children, style, ...rest }) {
  const selId = id || React.useId();
  return React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'var(--font-sans)' } },
    label && React.createElement('label', { htmlFor: selId, style: { fontSize: 13, fontWeight: 600, color: 'var(--color-text-secondary)' } }, label),
    React.createElement('select', {
      id: selId,
      style: {
        background: 'var(--color-surface)', color: 'var(--color-text)',
        border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)',
        padding: '9px 12px', fontSize: 14, fontFamily: 'inherit', outline: 'none', ...style
      },
      onFocus: e => e.currentTarget.style.boxShadow = 'var(--focus-ring)',
      onBlur: e => e.currentTarget.style.boxShadow = 'none',
      ...rest
    }, children)
  );
}
