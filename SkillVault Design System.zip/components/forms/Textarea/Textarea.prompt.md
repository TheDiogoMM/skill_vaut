Multi-line field, primarily for MCP config JSON (`mono` variant, inset background to read as a code well).

```jsx
<Textarea label="Config JSON (ex: bloco mcpServers)" mono required />
```
