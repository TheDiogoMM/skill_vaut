export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  /** Monospace, for JSON config */
  mono?: boolean;
}
export function Textarea(props: TextareaProps): JSX.Element;
