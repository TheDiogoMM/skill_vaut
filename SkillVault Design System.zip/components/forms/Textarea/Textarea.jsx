export function Textarea({ label, id, mono, style, ...rest }) {
  const taId = id || React.useId();
  return React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'var(--font-sans)' } },
    label && React.createElement('label', { htmlFor: taId, style: { fontSize: 13, fontWeight: 600, color: 'var(--color-text-secondary)' } }, label),
    React.createElement('textarea', {
      id: taId, rows: 6,
      style: {
        background: 'var(--color-bg-inset)', color: 'var(--color-text)',
        border: '1px solid var(--color-border)', borderRadius: 'var(--radius-md)',
        padding: '10px 12px', fontSize: mono ? 13 : 14, lineHeight: 1.5,
        fontFamily: mono ? 'var(--font-mono)' : 'inherit', outline: 'none', resize: 'vertical', ...style
      },
      onFocus: e => e.currentTarget.style.boxShadow = 'var(--focus-ring)',
      onBlur: e => e.currentTarget.style.boxShadow = 'none',
      ...rest
    })
  );
}
