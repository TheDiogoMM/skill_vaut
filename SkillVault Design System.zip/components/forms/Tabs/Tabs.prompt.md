Segmented control used by the Skill ingestion form to switch source type (Caminho local / Upload / URL).

```jsx
<Tabs
  tabs={[{value:'local_path',label:'Caminho local'},{value:'upload',label:'Upload'},{value:'url',label:'URL'}]}
  value={tab} onChange={setTab}
/>
```
