export function Tabs({ tabs, value, onChange }) {
  return React.createElement('div', { role: 'tablist', style: { display: 'inline-flex', gap: 2, background: 'var(--color-bg-inset)', padding: 3, borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' } },
    tabs.map(t => React.createElement('button', {
      key: t.value, type: 'button', role: 'tab', 'aria-selected': value === t.value,
      onClick: () => onChange(t.value),
      style: {
        fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, padding: '7px 14px',
        borderRadius: 'var(--radius-sm)', border: 'none', cursor: 'pointer',
        background: value === t.value ? 'var(--color-surface)' : 'transparent',
        color: value === t.value ? 'var(--color-text)' : 'var(--color-text-tertiary)',
        boxShadow: value === t.value ? 'var(--shadow-sm)' : 'none',
        transition: 'all var(--duration-fast) var(--ease-out)'
      }
    }, t.label))
  );
}
