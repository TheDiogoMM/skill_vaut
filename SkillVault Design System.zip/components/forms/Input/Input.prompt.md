Labeled single-line text field, used across all three ingestion forms (repo URL, skill name/path, MCP name).

```jsx
<Input label="Nome" placeholder="pdf-parser" required />
<Input label="URL do repositório" error="Informe uma URL git válida" />
```

Border turns `--color-danger` and shows the message below when `error` is set. Focus adds the standard focus ring (`--focus-ring`), never a color change alone.
