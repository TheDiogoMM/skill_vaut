export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  hint?: string;
  error?: string;
}
/**
 * @startingPoint section="Components" subtitle="Labeled text input with hint/error state" viewport="700x160"
 */
export function Input(props: InputProps): JSX.Element;
