export function Input({ label, hint, error, id, style, ...rest }) {
  const inputId = id || React.useId();
  return React.createElement('div', { style: { display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'var(--font-sans)' } },
    label && React.createElement('label', { htmlFor: inputId, style: { fontSize: 13, fontWeight: 600, color: 'var(--color-text-secondary)' } }, label),
    React.createElement('input', {
      id: inputId,
      style: {
        background: 'var(--color-surface)', color: 'var(--color-text)',
        border: `1px solid ${error ? 'var(--color-danger)' : 'var(--color-border)'}`,
        borderRadius: 'var(--radius-md)', padding: '9px 12px', fontSize: 14, fontFamily: 'inherit',
        outline: 'none', transition: 'border-color var(--duration-fast)', ...style
      },
      onFocus: e => e.currentTarget.style.boxShadow = 'var(--focus-ring)',
      onBlur: e => e.currentTarget.style.boxShadow = 'none',
      ...rest
    }),
    hint && !error && React.createElement('span', { style: { fontSize: 12, color: 'var(--color-text-tertiary)' } }, hint),
    error && React.createElement('span', { role: 'alert', style: { fontSize: 12, color: 'var(--color-danger)' } }, error)
  );
}
