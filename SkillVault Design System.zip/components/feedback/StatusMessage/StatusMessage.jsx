import { Icon } from '../../core/Icon/Icon.jsx';

const KIND = {
  success: { color: 'var(--color-success)', icon: 'check-circle-2' },
  error: { color: 'var(--color-danger)', icon: 'alert-circle' },
  info: { color: 'var(--color-text-secondary)', icon: 'info' }
};

export function StatusMessage({ kind = 'info', children }) {
  const c = KIND[kind] || KIND.info;
  return React.createElement('p', {
    role: kind === 'error' ? 'alert' : 'status',
    style: { display: 'flex', alignItems: 'center', gap: 6, margin: 0, fontFamily: 'var(--font-sans)', fontSize: 13, color: c.color }
  }, React.createElement(Icon, { name: c.icon, size: 15 }), children);
}
