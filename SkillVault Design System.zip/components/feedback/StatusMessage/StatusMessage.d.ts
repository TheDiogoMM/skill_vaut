export interface StatusMessageProps {
  kind?: 'success' | 'error' | 'info';
  children: React.ReactNode;
}
export function StatusMessage(props: StatusMessageProps): JSX.Element;
