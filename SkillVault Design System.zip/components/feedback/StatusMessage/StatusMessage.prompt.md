Inline status line for save/error/copy feedback (e.g. "Copiado!", "Erro ao salvar.", "nenhum MCP do catálogo cobre essa necessidade"). No toasts in this product — status is always inline, next to the action that triggered it.

```jsx
<StatusMessage kind="success">Salvo!</StatusMessage>
<StatusMessage kind="error">Não foi possível carregar o catálogo.</StatusMessage>
```
