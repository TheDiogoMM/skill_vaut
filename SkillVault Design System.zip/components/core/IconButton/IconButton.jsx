import { Icon } from '../Icon/Icon.jsx';

export function IconButton({ name, size = 18, label, active, style, ...rest }) {
  return React.createElement('button', {
    type: 'button', 'aria-label': label, title: label,
    style: {
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      width: 32, height: 32, borderRadius: 'var(--radius-md)',
      background: active ? 'var(--color-surface-hover)' : 'transparent',
      border: '1px solid transparent', color: active ? 'var(--color-text)' : 'var(--color-text-secondary)',
      cursor: 'pointer', transition: 'background var(--duration-fast) var(--ease-out)', ...style
    },
    onMouseEnter: e => e.currentTarget.style.background = 'var(--color-surface-hover)',
    onMouseLeave: e => e.currentTarget.style.background = active ? 'var(--color-surface-hover)' : 'transparent',
    ...rest
  }, React.createElement(Icon, { name, size }));
}
