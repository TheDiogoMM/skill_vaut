Square icon-only button for toolbars and nav rows (theme toggle, tag filter, external link).

```jsx
<IconButton name="sun" label="Alternar tema" onClick={toggleTheme} />
<IconButton name="search" label="Buscar" active />
```

Always pass `label` (used as `aria-label`/`title` — there's no visible text). `active` gives it a persistent surface background for toggled/current state.
