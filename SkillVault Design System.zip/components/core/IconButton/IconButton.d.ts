export interface IconButtonProps {
  name: string;
  size?: number;
  label: string;
  active?: boolean;
  onClick?: () => void;
}
export function IconButton(props: IconButtonProps): JSX.Element;
