Standard action button — used for form submits ("Adicionar repositório"), toolbar actions ("Copiar caminho"), and destructive actions.

```jsx
<Button variant="primary">Adicionar repositório</Button>
<Button variant="secondary" iconLeft={<Icon name="copy" size={14}/>}>Copiar caminho</Button>
<Button variant="ghost" size="sm">Cancelar</Button>
<Button variant="danger">Remover</Button>
```

Variants: `primary` (accent fill, main CTA — one per view), `secondary` (bordered, default for most actions), `ghost` (text-only, low emphasis / toolbar), `danger` (destructive). Sizes: `sm` / `md` / `lg`. Press state scales to 97%; disabled drops opacity to 50%.
