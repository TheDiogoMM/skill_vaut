export function Button({ variant = 'primary', size = 'md', iconLeft, iconRight, disabled, children, style, ...rest }) {
  const sizes = { sm: { padding: '6px 10px', fontSize: 13 }, md: { padding: '9px 14px', fontSize: 14 }, lg: { padding: '11px 18px', fontSize: 15 } };
  const variants = {
    primary: { background: 'var(--color-accent)', color: 'var(--color-text-on-accent)', border: '1px solid transparent' },
    secondary: { background: 'var(--color-surface-hover)', color: 'var(--color-text)', border: '1px solid var(--color-border-strong)' },
    ghost: { background: 'transparent', color: 'var(--color-text-secondary)', border: '1px solid transparent' },
    danger: { background: 'var(--color-danger)', color: '#fff', border: '1px solid transparent' }
  };
  const hoverBg = { primary: 'var(--color-accent-hover)', secondary: 'var(--color-surface-raised)', ghost: 'var(--color-surface-hover)', danger: 'var(--color-danger-hover)' };
  return React.createElement('button', {
    type: 'button', disabled,
    style: {
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      fontFamily: 'var(--font-sans)', fontWeight: 600, borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.5 : 1,
      transition: 'background var(--duration-fast) var(--ease-out), transform var(--duration-fast)',
      ...sizes[size], ...variants[variant], ...style
    },
    onMouseEnter: e => !disabled && (e.currentTarget.style.background = hoverBg[variant]),
    onMouseLeave: e => !disabled && (e.currentTarget.style.background = variants[variant].background),
    onMouseDown: e => !disabled && (e.currentTarget.style.transform = 'scale(.97)'),
    onMouseUp: e => !disabled && (e.currentTarget.style.transform = 'scale(1)'),
    ...rest
  }, iconLeft, children, iconRight);
}
