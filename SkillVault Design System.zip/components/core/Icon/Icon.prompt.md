Thin wrapper around Lucide icons (CDN, no local SVGs) — SkillVault's codebase has no icon system of its own, so Lucide (outline, 2px stroke) was chosen as the closest CDN match.

```jsx
<Icon name="search" size={16} />
<Icon name="git-branch" size={18} style={{ color: 'var(--color-type-repo)' }} />
```

Each `<Icon>` lazily loads the Lucide CDN script on first mount and re-scans, so no separate setup call is needed. Icon color follows `currentColor`/CSS `color`; set it via `style`.
