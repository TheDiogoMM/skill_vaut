/**
 * @startingPoint section="Foundation" subtitle="Lucide icon wrapper" viewport="700x160"
 */
export interface IconProps {
  /** Lucide icon name, e.g. "search", "copy", "git-branch", "sparkles", "server" */
  name: string;
  /** Pixel size (square). Default 16. */
  size?: number;
  strokeWidth?: number;
}
export function Icon(props: IconProps): JSX.Element;
