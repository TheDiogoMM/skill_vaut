export function Icon({ name, size = 16, strokeWidth = 2, style, ...rest }) {
  React.useEffect(() => {
    if (window.__lucideLoading || window.lucide) { window.lucide && window.lucide.createIcons(); return; }
    window.__lucideLoading = true;
    const s = document.createElement('script');
    s.src = 'https://unpkg.com/lucide@latest/dist/umd/lucide.js';
    s.onload = () => window.lucide && window.lucide.createIcons();
    document.head.appendChild(s);
  }, [name]);
  return React.createElement('i', {
    'data-lucide': name,
    style: { width: size, height: size, display: 'inline-flex', flexShrink: 0, ...style },
    'data-stroke-width': strokeWidth,
    ...rest
  });
}
